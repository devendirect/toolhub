# Organisation de `components/`

Ce document explique la logique de rangement adoptée dans ce projet et les principes derrière, pour pouvoir les reproduire.

---

## Le principe général

Les dossiers sont organisés **par domaine fonctionnel**, pas par type technique.

On ne fait PAS :
```
components/
  buttons/
  inputs/
  modals/
```

On fait :
```
components/
  brand/       ← identité visuelle
  layout/      ← structure de page
  home/        ← spécifique à la homepage
  ...
```

Pourquoi ? Quand tu travailles sur une feature, tous les fichiers dont tu as besoin sont au même endroit. Tu ne cherches pas un `Button` dans `/inputs`, un `Modal` dans `/modals`, et la logique dans `/utils` — tout ce qui concerne la palette de commandes est dans `/palette`.

---

## Règle de décision : où mettre un nouveau composant ?

```
Est-ce que ce composant est utilisé sur UNE seule page/section ?
  → dossier de cette page (ex: home/, tool/)

Est-ce que c'est une primitive réutilisable partout ?
  → dossier thématique (brand/, workspace/, ui/)

Est-ce que c'est de l'infrastructure (contexte, provider) ?
  → providers/
```

---

## Les dossiers

### `ui/`
Composants générés automatiquement par **shadcn/ui**. Ne pas modifier à la main — toujours passer par `npx shadcn add <composant>`. Contient les primitives de bas niveau : Button, Input, Dialog, Tabs, etc.

> Règle : on n'importe jamais depuis `ui/` directement dans les pages. On passe toujours par un wrapper maison si le composant a besoin d'un style ou comportement propre au projet.

---

### `providers/`
Les **React Context providers** et leurs hooks associés. Chaque provider est dans son propre fichier. `Providers.tsx` les compose tous ensemble — c'est le seul fichier importé dans `layout.tsx`.

```
I18nProvider.tsx    → contexte langue (fr/en) + hook useLang()
ThemeProvider.tsx   → contexte thème (accent, density, font) + hook useTheme()
PaletteProvider.tsx → contexte palette (open/close) + hook usePalette()
Providers.tsx       → compose les trois, importé dans app/layout.tsx
```

> Règle : un seul hook par provider. Si le provider devient complexe, il peut avoir un fichier `useXxx.ts` séparé dans le même dossier.

---

### `brand/`
Les composants qui **portent l'identité visuelle** du produit. Ils n'ont pas de logique métier — ils sont purement visuels et réutilisés partout.

```
LogoMark.tsx   → SVG du logo (grille 2×2)
Cursor.tsx     → curseur clignotant █ animé (animate-blink)
PromptBar.tsx  → ligne "$ commande" avec le curseur
```

> Règle : aucun appel API, aucun état, aucun hook de domaine ici. Si ça change en fonction d'une logique métier, ça n'appartient pas à brand/.

---

### `layout/`
Les composants qui **structurent chaque page** — présents sur toutes les routes.

```
AppShell.tsx   → fond dot-grid + scanline + Header + main + Footer + CommandPalette
Header.tsx     → nav, logo, lang switch, bouton ⌘K, statut operational
Footer.tsx     → 4 colonnes + ligne terminale de bas de page
```

> Règle : ces composants ne connaissent pas le contenu des pages. Ils fournissent le cadre, les pages remplissent le cadre. AppShell est le seul endroit où Header et Footer sont importés.

---

### `palette/`
Tout ce qui concerne la **palette de commandes** (⌘K). Un seul composant ici aujourd'hui, mais il est assez complexe (scoring custom, grouping, navigation clavier) pour mériter son propre dossier.

```
CommandPalette.tsx   → cmdk, scoring custom, groupes par catégorie, ToolRow
```

> Règle : si un composant dépasse ~150 lignes et a sa propre logique isolée, il peut avoir son propre dossier plutôt que d'aller dans un dossier générique.

---

### `home/`
Composants **utilisés uniquement sur la homepage** (`app/page.tsx`). Ils ne sont pas réutilisés ailleurs.

```
SectionHead.tsx      → titre de section + ligne horizontale + action optionnelle
StatBlock.tsx        → bloc stat (label / valeur / sous-label)
ToolCard.tsx         → carte d'outil dans la grille (lien vers /t/slug)
FeaturedCard.tsx     → carte mise en avant (3 colonnes, badge FEATURED)
CategoryChips.tsx    → pills de filtre par catégorie (état actif)
CategorySection.tsx  → SectionHead + grille de ToolCards pour une catégorie
```

> Règle : dès qu'un composant de `home/` est utilisé dans une deuxième page, il monte d'un niveau dans un dossier plus générique.

---

### `tool/`
Composants de la **page outil** (`app/t/[slug]/page.tsx`). Ils connaissent le type `Tool` et savent l'afficher.

```
ToolHeader.tsx      → breadcrumb + glyph + titre + description + boutons + TrustSignals
TrustSignals.tsx    → dot vert (local) ou orange (network) + message adapté
ToolPageClient.tsx  → orchestre tout : ToolHeader + Workspace + API snippet + outils liés
```

> Note : `ToolPageClient` est un "page-level component" — il assemble les blocs mais ne contient pas de logique métier propre. Il vit dans `tool/` et pas dans `app/` parce qu'il est client (`"use client"`) et que `app/t/[slug]/page.tsx` doit rester serveur pour `generateStaticParams` et `generateMetadata`.

---

### `catalog/`
Composants de la **page catalogue** (`app/tools/` et `app/tools/[category]/`).

```
CatalogPageClient.tsx   → orchestre tout : breadcrumb + head + sidebar + liste
```

Contient en interne (pas de fichiers séparés) : la sidebar de filtres (recherche, catégories, tri, tags populaires) et les lignes de la liste. Un seul fichier car c'est une seule page avec un seul état partagé.

> Note : `CatalogPageClient` accepte `initialCat` en prop (passé depuis les pages serveur). L'état interne prend le relais pour les filtres client — l'URL ne se met pas à jour quand on change de catégorie dans la sidebar (comportement intentionnel pour Phase 2).

---

### `workspace/`
Les **primitives de l'espace de travail** — les briques réutilisables par tous les workspaces.

```
Editor.tsx      → wrapper CodeMirror 6 avec theme dark custom
Pane.tsx        → panneau (header avec titre/meta/actions, body, footer)
OptionsBar.tsx  → barre d'options (OptBlock, SegControl, Toggle)
```

> Règle : ces composants ne savent pas quel outil ils affichent. Ils reçoivent du contenu via props/children. La logique JSON est dans `workspaces/JsonFormatter`, pas dans `Editor`.

---

### `workspaces/`
Les **implémentations concrètes** de chaque outil. Un fichier par outil.

```
JsonFormatter.tsx    → formatage JSON (indent, sort, minify) avec CodeMirror
GenericWorkspace.tsx → fallback pour les outils pas encore implémentés
```

À venir (Phase 2+) :
```
QrGenerator.tsx
Base64Tool.tsx
ImageConverter.tsx
ColorPalette.tsx
PdfMerge.tsx
...
```

> Règle : chaque workspace reçoit `{ tool: Tool }` en props et gère son propre état. Il utilise les primitives de `workspace/` mais ne les modifie pas.

---

## Résumé visuel

```
components/
│
├── ui/              ← shadcn (auto-généré, ne pas toucher)
├── providers/       ← React Context (infrastructure)
│
├── brand/           ← identité visuelle pure (logo, curseur)
├── layout/          ← structure de toutes les pages (shell, header, footer)
├── palette/         ← CommandPalette ⌘K
│
├── home/            ← spécifique à app/page.tsx
├── tool/            ← spécifique à app/t/[slug]/page.tsx
│
├── workspace/       ← primitives réutilisables des workspaces
└── workspaces/      ← implémentations des outils (1 fichier = 1 outil)
```

---

## Distinction `workspace/` vs `workspaces/`

C'est la seule subtilité de nommage :

| Dossier | Contient | Analogie |
|---|---|---|
| `workspace/` | Primitives (Editor, Pane, OptionsBar) | Les outils de la boîte à outils |
| `workspaces/` | Implémentations (JsonFormatter, QrGenerator…) | Les objets construits avec ces outils |

Une alternative plus explicite si tu reprends ce pattern dans un autre projet :
```
workspace/primitives/   → Editor, Pane, OptionsBar
workspace/tools/        → JsonFormatter, QrGenerator...
```

---

## Ce pattern s'appelle "Feature Folders"

C'est une convention largement adoptée dans les projets React/Next.js modernes. La règle principale : **un dossier = une raison de changer**. Si tu modifies la homepage, tu touches `home/`. Si tu ajoutes un outil, tu touches `workspaces/`. Les deux opérations n'ont aucune raison d'interférer.
