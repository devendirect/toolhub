## TypeScript Review — toolhub
**Date:** 2026-06-14

---

### ✅ Bon typage détecté

- **`"strict": true`** dans `tsconfig.json` — active `strictNullChecks`, `noImplicitAny`, etc.
- **`interface Tool`** bien définie dans `lib/types.ts` — champs optionnels marqués `?`, union types pour `cat` et `privacy`.
- **`Localized = Record<Lang, string>`** — pattern propre, réutilisé dans `name`, `desc`, `label`.
- **`type Lang = "fr" | "en"`** — union littérale, pas de `string` libre.
- **`type Dict = (typeof dict)[Lang]`** — type inféré depuis la constante, garantit la cohérence entre les deux langues.
- **Props typées sans `React.FC`** — ex: `function ToolCard({ tool, lang, catLabel }: ToolCardProps)` dans tous les composants.
- **Route handlers typés** — `export async function GET(req: NextRequest): Promise<NextResponse>` implicite via les types Next.js.
- **`params: Promise<{ slug: string }>`** — typage Next.js 15 correct pour les pages avec params asynchrones.
- **`SeoCheck` interface exportée** — `app/api/seo/route.ts:11` — les types de réponse API sont définis.

---

### ⚠️ Conventions à revoir

**`tsconfig.json` — options strictes supplémentaires non activées**
```json
// Manquant :
"noUncheckedIndexedAccess": true,
"noImplicitReturns": true
```
> `noUncheckedIndexedAccess` force `array[i]` à retourner `T | undefined` — prévient les bugs d'index hors-limites. `noImplicitReturns` garantit que toutes les branches d'une fonction retournent une valeur.

**Non-null assertion non sécurisée** — `components/home/HomeClient.tsx:27`
```tsx
const featured = TOOLS.find((t) => t.slug === "json-formatter")!;
```
> Le `!` ment au compilateur : si le slug change, `featured` est `undefined` au runtime. TypeScript ne peut pas détecter ce bug.
→ `const featured = TOOLS.find((t) => t.slug === "json-formatter") ?? TOOLS[0];`

**`makeCache` retourne `T | null` mais le type générique est non contraint** — `lib/route-security.ts:61`
```ts
export function makeCache<T>(ttlMs: number, maxSize: number) {
```
> Fonctionne mais `T` pourrait être contraint à `object` ou `Record<string, unknown>` pour éviter une utilisation avec des primitives qui serait incorrecte avec `null` comme sentinel.

**`as const` manquant sur le dict i18n** — `lib/i18n.ts:3`
```ts
export const dict = { fr: { ... }, en: { ... } } as const;
```
> Déjà présent — ✅ c'est correct.

---

### 🔴 Typage dangereux

**`data: unknown` non étroit dans `/api/ip`** — `app/api/ip/route.ts:117`
```ts
const data = await res.json(); // retourne any
```
> `res.json()` retourne `any`. La valeur est ensuite passée à `cacheSet(target, data)` qui accepte `unknown`, puis retournée directement au client. Aucun problème de sécurité car on ne lit pas de champs, mais un type explicite `IpApiResponse` renforcerait la confiance.

**`as [Sort, string][]` cast forcé** — `components/catalog/CatalogPageClient.tsx:169`
```ts
([["popularity", i.sortPop], ["name", i.sortName], ["new", i.sortNew]] as [Sort, string][])
```
> Le cast force le type — si `Sort` évolue, la liste ne sera pas vérifiée. Utiliser un tableau de `{key: Sort; label: string}` à la place.

---

### 💡 Suggestions

**Utility types** — `lib/types.ts`
> `Pick<Tool, 'slug' | 'name' | 'cat'>` pourrait être utilisé pour le type des items dans la CommandPalette au lieu de passer `Tool` entier.

**`ReturnType<typeof makeRateLimiter>`** — pourrait être exporté comme type nommé pour les tests futurs.

**`generateMetadata` type de retour** — `app/t/[slug]/page.tsx:11`
```ts
export async function generateMetadata({ params }: Props): Promise<Metadata>
```
> Quand `!tool`, retourne `{}` (objet vide) — les champs `title` et `description` seront hérités du layout root mais sans signal de 404. Retourner `{ robots: { index: false } }` serait plus correct.

---

### Progression
- [x] `strict: true` activé
- [x] Pas de `any` dans les props ou retours de composants
- [x] `React.FC` non utilisé
- [x] Union types pour les variantes (cat, privacy, lang)
- [x] `noImplicitReturns` activé dans tsconfig
- [x] Non-null assertion `featured` remplacée (`?? TOOLS[0]`)
- [x] `noUncheckedIndexedAccess` activé — accès `split()[0].trim()` sécurisés avec `?.[0]?.trim()`, PdfMerge swap via temp vars, PasswordGenerator passe `pw` directement, CronGenerator fusionne FIELDS+FIELD_KEYS, PdfConverter passe en `for...of entries()`, HomeHero fusionne CORNERS+POSITIONS
- [x] Types de réponse API explicites — `IpApiResponse` interface dans app/api/ip/route.ts
- [x] Cast `as [Sort, string][]` remplacé — tableau `{ key: Sort; label: string }[]` avec `satisfies`
