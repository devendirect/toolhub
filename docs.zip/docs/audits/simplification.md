## Code Simplification Review — toolhub
**Date:** 2026-06-14

---

### ✅ Points positifs

- `lib/route-security.ts` — utilitaires extraits et partagés entre les 3 routes API. Bon exemple de DRY.
- `ToolCard` et les rows de `CatalogPageClient` suivent un pattern `if (soon) return div else return Link` cohérent.
- `useMemo` dans `CatalogPageClient` évite les recalculs inutiles du filtre.
- `lib/brand.ts` centralise `BRAND_NAME` et `BRAND_TAGLINE`.

---

### ⚠️ Duplication (DRY)

**Pattern bilingue `lang === "fr" ? "..." : "..."` dupliqué ~20 fois**
> Voir la liste exhaustive dans `docs/audits/i18n.md`. Ce pattern est la duplication la plus répandue du projet. Chaque string inline est dupliquée en FR et EN dans le JSX au lieu d'être dans le dict.

**Logique de grille density répétée** — `components/home/HomeClient.tsx:118`
```tsx
`grid ${density === "compact" ? "grid-cols-4" : density === "comfy" ? "grid-cols-2" : "grid-cols-3"}`
```
> Ce ternaire imbriqué apparaît ou va apparaître dans plusieurs composants (HomeClient favoris, CategorySection…). À extraire en utilitaire :
```tsx
function densityGrid(density: string) {
  if (density === "compact") return "grid-cols-4";
  if (density === "comfy")   return "grid-cols-2";
  return "grid-cols-3";
}
```

**Header de pane dupliqué dans `GenericWorkspace`** — `components/workspaces/GenericWorkspace.tsx:32-37` et `:56-61`
> Les deux panes (input/output) ont un header identique en structure. Pourrait être un composant `PaneHeader`.

---

### ⚠️ Code mort

**Sort "new" ne fait rien** — `components/catalog/CatalogPageClient.tsx:42`
```ts
if (sort === "new") return 0; // trie rien
```
> L'option "récent" est affichée dans l'UI mais ne produit aucun effet. C'est du code mort fonctionnel.

**Clés i18n orphelines dans `lib/i18n.ts`**
> `docs`, `status`, `api`, `contact` — présents dans FR et EN, mais les liens footer correspondants ont été supprimés. Aucun composant ne les référence.

**`POPULAR_TAGS` constant hardcodée** — `components/catalog/CatalogPageClient.tsx:14`
```ts
const POPULAR_TAGS = ["json", "pdf", "image", "encode", "color", "webp", "qr"];
```
> Liste statique non dérivée des données. Si les tags évoluent dans `lib/tools.ts`, cette liste ne se met pas à jour. À dériver automatiquement (top N tags par fréquence) ou à exporter depuis `lib/tools.ts`.

**Import `StatBlock`** — `components/catalog/CatalogPageClient.tsx:11`
> `StatBlock` est encore utilisé (ligne 89 pour le count filtré), donc l'import est valide. Cependant, si `StatBlock` affiche encore des runs dans sa logique interne, vérifier qu'il ne montre que `filtered.length`.

---

### ⚠️ Complexité

**`CatalogPageClient` — 280 lignes, tout en un fichier**
> La sidebar (search + categories + sort + tags), le header, et la liste sont dans un seul Client Component. La complexité cyclomatique n'est pas critique (les branches sont claires) mais la longueur rend le fichier difficile à lire.
→ Extraire : `<CatalogSidebar>` (categories + sort + tags) et `<CatalogList>` (rows).

**`HomeClient` — contextes multiples**
```tsx
const { lang }    = useLang();
const { setOpen } = usePalette();
const { density } = useTheme();
const { favorites } = useFavorites();
```
> 4 contextes consommés dans un même composant. Chaque mise à jour de n'importe lequel de ces contextes re-render tout `HomeClient`. Ce n'est pas un problème de performance immédiat (données statiques) mais c'est un signal d'architecture.

---

### 💡 Lisibilité

**Ternaire imbriqué pour le badge proxy/catégorie** — `components/home/ToolCard.tsx:30-34`
```tsx
{!soon && (tool.privacy === "network" ? (
  <span>● proxy</span>
) : (
  <span>{catLabel}</span>
))}
```
→ Lisible mais une variable intermédiaire `const badge = tool.privacy === "network" ? ...` clarifierait l'intention.

**`[…corners].map()` dans HomeClient** — `components/home/HomeClient.tsx:50-58`
> Un `.map()` sur un tableau de positions CSS pour rendre 4 caractères ASCII. Fonctionnel mais surprenant — un lecteur ne voit pas immédiatement que c'est 4 coins. Un commentaire ou 4 `<span>` inline serait plus lisible.

---

### Progression
- [x] Utilitaires route-security extraits (DRY entre API routes)
- [x] Pattern bilingue inline migré — heroDesc, catalogAll, catalogCat, viewAll, popularTags ajoutés ; sortNew supprimé
- [x] Sort "new" supprimé — type `Sort`, tableau d'options et branche `.sort()` nettoyés
- [x] Clés i18n orphelines supprimées (`docs`, `status`, `api`, `contact`)
- [x] POPULAR_TAGS dérivé des données — calculé à l'init depuis TOOLS dans lib/tools.ts
- [x] densityGrid extrait — lib/theme.ts `densityGridCols()`, utilisée dans HomeClient
- [x] CatalogPageClient fragmenté — CatalogSidebar.tsx + CatalogList.tsx + hub allégé à ~60 lignes
