## Error Handling Review — toolhub
**Date:** 2026-06-14
**Framework:** Next.js App Router
**Monitoring:** Aucun

---

### ✅ Bonnes pratiques détectées

- **API routes** — toutes les erreurs retournent un JSON `{ error: "..." }` avec le bon status HTTP (400, 413, 422, 429, 502). Aucun `throw` non catché.
- **Timeout avec AbortController** — les 3 routes API ont un timeout (8s ou 10s) avec `clearTimeout` dans le catch. La distinction AbortError vs autre erreur est faite.
- **`notFound()`** — appelé dans `app/t/[slug]/page.tsx:26` quand le slug est introuvable.
- **Fallback clipboard dans `ToolHeader`** — si `navigator.share` n'est pas supporté, repli sur `clipboard.writeText` + feedback visuel `setShared(true)`.
- **FavoritesProvider** — `localStorage` wrappé dans `try/catch` (lecture et écriture), évite les crashes en mode privé ou si le storage est plein.

---

### 🔴 Erreurs non gérées

**`navigator.clipboard.writeText`** ✅ — `components/tool/ToolHeader.tsx` — wrappé dans try/catch. En cas de refus de permission, crash silencieux sans impact UX.

---

### ⚠️ Next.js Error Files

**`error.tsx`** ✅ créé — `app/error.tsx` — affiche le message d'erreur + bouton "try again ↺", log dans la console.

**`not-found.tsx`** ✅ créé — `app/not-found.tsx` — style terminal, liens vers home et /tools.

**`global-error.tsx`** — absent. Les erreurs dans `RootLayout` ou les Providers ne sont pas capturées.
→ Créer `app/global-error.tsx` (minimaliste : rechargement de page).

---

### ⚠️ Error Boundaries absents

**Aucune `ErrorBoundary` classe** — codebase entier
> Les erreurs runtime dans les Client Components (workspaces, CommandPalette, FavoritesProvider) provoquent un écran blanc sans récupération possible.
→ Ajouter une `ErrorBoundary` au minimum autour de chaque workspace dans `ToolPageClient`, et autour de `CommandPalette`.

---

### ⚠️ Messages utilisateur

**Pas de feedback d'erreur dans les workspaces** — `GenericWorkspace.tsx`
> Le workspace générique est un stub, pas de logique d'erreur ici. Mais pour les workspaces réels (JsonFormatter, etc.), s'assurer que les erreurs de parsing montrent un message lisible, pas un stack trace.

**Toasts disponibles mais non utilisés pour les erreurs** — `Providers.tsx:8`
> `<Toaster />` de Sonner est configuré. Les API routes retournent des erreurs JSON mais aucune logique client ne les intercepte de façon centralisée pour les afficher.

---

### ⚠️ Monitoring

- Aucun Sentry ou équivalent. Acceptable au stade actuel, mais à prévoir avant la mise en production publique.
- Les erreurs API sont loggées via `return NextResponse.json({ error: msg })` mais non tracées côté serveur.

---

### Progression
- [x] Promesses API gérées (try/catch dans les 3 routes)
- [x] Timeouts avec AbortController
- [x] localStorage wrappé (FavoritesProvider)
- [x] `navigator.clipboard.writeText` protégé
- [x] `error.tsx` défini (app/error.tsx)
- [x] `not-found.tsx` défini (app/not-found.tsx)
- [x] `global-error.tsx` défini (app/global-error.tsx)
- [x] ErrorBoundary autour des workspaces (components/ErrorBoundary.tsx, utilisée dans ToolPageClient)
- [ ] Sentry (ou équivalent) configuré
