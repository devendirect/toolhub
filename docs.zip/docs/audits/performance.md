## Performance Audit — Next.js
**Date:** 2026-06-14
**Router:** App Router
**Deployment:** Standard

---

### ✅ Bonnes pratiques détectées

- **`next/font/google`** — Geist Sans, Geist Mono, JetBrains Mono chargés via `next/font` dans `app/layout.tsx`. Subsets `latin` spécifiés. Élimine le FOIT/CLS lié aux polices.
- **`generateStaticParams()`** — Toutes les pages `/t/[slug]` sont pré-rendues statiquement (`app/t/[slug]/page.tsx:21`). Zéro latence serveur pour les pages outils.
- **`useMemo` dans `CatalogPageClient`** — Le filtrage + tri de 51 outils (25 live + 26 comingSoon) est mémoïsé (`components/catalog/CatalogPageClient.tsx:27`).
- **Pas d'images** — L'interface est 100% texte/ASCII. La problématique `next/image` / LCP image ne s'applique pas.
- **Pas de barrel files détectés** — Les imports sont directs (`@/lib/tools`, `@/lib/i18n`, etc.).
- **ffmpeg.wasm en lazy-load** — Documenté dans CLAUDE.md comme règle. Non encore implémenté mais l'architecture l'anticipe.
- **Statique par défaut** — Toutes les pages qui le peuvent sont Server Components sans `dynamic = 'force-dynamic'`.

---

### ⚠️ Problèmes modérés

**Aucun `loading.tsx` défini** — aucun fichier trouvé dans `app/`
> Pas de streaming pour les routes avec données asynchrones. Les pages `tools/[category]` et tool pages bloquent jusqu'à hydratation complète.
→ À créer : `app/loading.tsx`, `app/t/[slug]/loading.tsx` (squelette minimal).

**Aucune `<Suspense>` boundary** — codebase entier
> Les Client Components lourds comme `CatalogPageClient` et `HomeClient` (qui chargent les contextes Favorites, Theme, I18n) ne sont pas streamés indépendamment.
→ Les workspaces futurs (ffmpeg, PDF) devront absolument être wrappés en `<Suspense>`.

**`HomeClient` est un gros Client Component** — `components/home/HomeClient.tsx:1`
> 160 lignes, importe 5 contextes. La section Hero est statique mais est bundlée côté client à cause du `useState` sur le filtre de catégorie.
→ Opportunité : extraire Hero et FeaturedCard en Server Components, ne garder que le filtre en client.

**Sort "recent" sans implémentation** — `components/catalog/CatalogPageClient.tsx:42`
```ts
if (sort === "new") return 0; // ne trie rien
```
→ Pas un bug de performance mais une fonctionnalité morte. Ajouter un champ `addedAt` sur Tool ou supprimer l'option.

---

### 💡 Quick wins

- **`display: 'swap'`** non spécifié dans `next/font` calls — Next.js l'applique par défaut mais l'expliciter est plus lisible.
- **Trois fonts Google chargées** (Geist Sans, Geist Mono, JetBrains Mono) — chaque font = une requête réseau. Vérifier si JetBrains Mono est effectivement utilisée au rendu (le `data-font="geist"` par défaut peut la rendre inutile au démarrage).
- **Bundle analyzer** — `ANALYZE=true next build` n'a pas été lancé. À faire avant le premier déploiement pour vérifier que cheerio et les libs workspace ne contaminent pas le bundle client.

---

### Progression
- [x] Fonts via next/font
- [x] Stratégie de rendu correcte (statique par défaut, generateStaticParams)
- [x] Fetching parallélisé (pas de fetching serveur asynchrone en cascade)
- [x] Pas de barrel files
- [x] loading.tsx en place — app/loading.tsx + app/t/[slug]/loading.tsx
- [x] Sort "recent" supprimé
- [x] HomeClient fragmenté — HomeHero (pur) + HomeSections (client, gère activeCat) + HomeClient (hub)
- [x] Lazy loading workspaces lourds — AudioConverter, VideoConverter, PdfConverter chargés via `next/dynamic` + `{ ssr: false }` + fallback squelette ; ffmpeg.wasm et pdfjs-dist exclus du bundle principal
- [ ] Bundle analysé (ANALYZE=true next build)
