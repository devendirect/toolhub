## SEO Review — Next.js
**Date:** 2026-06-14
**Router:** App Router
**Deployment:** Standard

---

### ✅ Bonne implémentation détectée

- **`generateMetadata()`** sur les pages tool — titres et descriptions dynamiques par outil (`app/t/[slug]/page.tsx:11`).
- **`generateStaticParams()`** — toutes les pages `/t/[slug]` pré-rendues statiquement. Temps de réponse < 10ms → bonne indexation.
- **`next/font`** — Geist et JetBrains Mono chargées sans `@import` CSS. Élimine le font-CLS (bon pour Core Web Vitals).
- **Titres uniques** — chaque page tool a un titre distinct (`tool.name.en — BRAND_NAME`).
- **`notFound()`** — les slugs invalides renvoient un 404 HTTP réel (pas un 200 avec page vide).
- **Pas d'images à optimiser** — interface purement textuelle/ASCII, pas de problème LCP image.
- **Metadata sur `/tools`** — `app/tools/page.tsx` définit un titre et une description explicites.

---

### 🔴 Problèmes critiques

**`metadataBase`** ✅ — ajouté dans `app/layout.tsx` : `new URL(process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000")`. À définir en variable d'env sur le serveur de production.

**Open Graph** ✅ — ajouté sur toutes les pages :
- Root layout : `openGraph.type`, `openGraph.siteName`, `twitter.card`
- Homepage (`/`) : titre et description OG dédiés
- `/tools` : titre et description OG dédiés
- `/t/[slug]` : `og:title` et `og:description` dynamiques par outil

**`title.template`** ✅ — root layout utilise `title.template: "%s — toolhub"`. Les pages `/tools` et `/t/[slug]` passent désormais un titre court qui hérite automatiquement du template.

**Aucun `robots.txt`** — `/robots.txt` non accessible
> Sans `robots.txt`, Googlebot crawl tout le site y compris `/api/*` qui devrait être exclu.
→ Créer `app/robots.ts` avec `disallow: ["/api/"]`.

**Aucun `sitemap.xml`** — `/sitemap.xml` non accessible
> Google doit découvrir les 25 pages outils par crawl ordinaire. Un sitemap accélère l'indexation et permet de donner les dates de modification.
→ Créer `app/sitemap.ts` listant `/`, `/tools`, `/tools/[category]`, `/t/[slug]`.

---

### ⚠️ Metadata manquante ou incorrecte

**`title.template` absent** — `app/layout.tsx`
> Les titres de pages n'héritent pas automatiquement d'un format `"page | BRAND"`. Chaque page doit construire son titre manuellement.
```tsx
title: {
  default: BRAND_NAME,
  template: `%s — ${BRAND_NAME}`,
}
```
Avec ce template, `generateMetadata` n'aurait besoin que de retourner `{ title: tool.name.en }`.

**Canonical URLs absentes** — toutes les pages
> Aucune page ne définit de `<link rel="canonical">`. Si le domaine est accessible avec et sans `www`, ou via plusieurs URLs, les moteurs verront du contenu dupliqué.
→ Ajouter `alternates: { canonical: "https://toolhub.app/t/[slug]" }` dans `generateMetadata`.

**Description homepage trop longue** — `app/page.tsx:7`
```
"25 free tools, no signup required. JSON formatter, Base64 encoder, UUID generator, QR codes, PDF converter, SEO analyzer, password generator and more. Most tools run 100% in your browser."
```
> 196 caractères — au-dessus de la limite recommandée de 160. Google tronquera le snippet.
→ Réduire à ~150 caractères.

**Titres en anglais uniquement** — `app/layout.tsx:25`, `app/t/[slug]/page.tsx:15`
> Les titres et descriptions meta sont uniquement en anglais même quand l'utilisateur est en mode FR. Pour un site bilingue, idéalement deux variantes de metadata par page ou, au minimum, choisir une langue fixe et cohérente (et y rester).
→ Décision à prendre : site EN par défaut (pour le SEO international) ou FR avec `hreflang`. Ne pas mélanger.

---

### ⚠️ Twitter / Social Cards

**Aucun Twitter Card** — toutes les pages
> Sans `twitter:card`, les partages X/Twitter affichent juste un lien plain text.
→ Ajouter dans le root layout :
```tsx
twitter: { card: "summary", site: "@toolhub" }
```

---

### ⚠️ i18n SEO

**`hreflang` absent** — site bilingue sans signaux i18n pour les moteurs
> Google ne saura pas que `/` et la même page en EN sont équivalents. Pas critique si la langue est gérée par state client (pas par URL), mais à noter.

**`lang="fr"` fixe sur `<html>`** — `app/layout.tsx:32`
> Même si l'utilisateur bascule en EN, le signal HTML reste `fr`. À harmoniser avec la décision de langue par défaut.

---

### 💡 Structured Data (JSON-LD)

Aucun JSON-LD détecté. Pour un site d'outils, les schemas utiles sont :
- **`WebApplication`** sur les pages outils (nom, description, catégorie, plateforme "Web", gratuité)
- **`Organization`** sur la home
- **`BreadcrumbList`** sur les pages outils (Home → Tools → [outil])

Ce n'est pas bloquant pour l'indexation mais peut générer des rich results dans Google Search.

---

### Progression
- [x] Titres uniques par page
- [x] `next/font` (bon pour CWV)
- [x] `generateStaticParams()` (bon pour indexation)
- [x] 404 HTTP réel via `notFound()`
- [x] `metadataBase` défini dans le root layout (via NEXT_PUBLIC_SITE_URL)
- [x] Open Graph sur toutes les pages (titre, description)
- [x] `title.template` dans le root layout
- [x] Description homepage réduite (< 160 chars)
- [x] Twitter Cards configurées (summary)
- [x] `robots.ts` créé — bloque tout si `INDEXING_ENABLED !== "true"`, sinon exclut `/api/`
- [x] `sitemap.ts` créé — routes statiques + 25 outils live (comingSoon exclus)
- [x] Canonical URLs dans `generateMetadata` des pages tool
- [x] Pages `comingSoon` en `robots: { index: false }` même si l'indexation est activée
- [ ] Décision langue par défaut (EN ou FR) et `hreflang` si besoin
- [ ] JSON-LD WebApplication sur les pages outils (optionnel)
