## Security Audit — Next.js
**Date:** 2026-06-14
**Router:** App Router
**Deployment:** Standard (Node/Vercel)

---

### ✅ Bonnes pratiques détectées

- **SSRF protection complète** — `lib/route-security.ts` bloque tous les ranges privés (10.x, 172.16-31.x, 192.168.x, 169.254.x/AWS metadata, CGNAT), loopback, et TLDs internes (`.local`, `.internal`, `.corp`…). Utilisé par `/api/meta` et `/api/seo`.
- **Rate limiting sur les 3 routes** — 10 req/min par IP requérante, avec nettoyage périodique pour éviter la fuite mémoire.
- **Validation du format IP** — `/api/ip` valide IPv4 et IPv6 avant d'appeler ip-api.com.
- **Validation du protocole** — `isSafeUrl()` rejette les schémas non-http(s) (`javascript:`, `file:`, etc.).
- **Limite de taille réponse** — `checkResponseSize()` bloque les réponses > 5 Mo.
- **Timeout sur les fetches externes** — 8s sur `/api/ip`, 10s sur `/api/meta` et `/api/seo`. AbortController bien utilisé.
- **Cache en mémoire** — évite les appels répétés à des services tiers.
- **COEP/COOP headers** — configurés dans `next.config.ts` pour ffmpeg.wasm (SharedArrayBuffer).
- **Pas de secrets côté client** — aucun `process.env.SECRET` ni `NEXT_PUBLIC_SECRET` détecté.
- **Aucun `dangerouslySetInnerHTML` avec contenu utilisateur** — le seul usage potentiel de contenu externe est parsé via cheerio côté serveur.

---

### ⚠️ Risques modérés

**Headers de sécurité** ✅ — `next.config.ts` mis à jour. `X-Frame-Options: DENY`, `X-Content-Type-Options: nosniff`, `Referrer-Policy: strict-origin-when-cross-origin` ajoutés.

**`checkResponseSize` contournable** — `lib/route-security.ts:83`
> La vérification repose uniquement sur le header `Content-Length`, que les serveurs peuvent omettre. Une réponse chunked volumineuse passerait sans être bloquée.
→ Risque : DoS mémoire si un site cible renvoie une réponse streaming de plusieurs Go. Solution : lire en stream avec compteur de bytes.

**Rate limiting non persistant** — `app/api/ip/route.ts` & `lib/route-security.ts`
> Les maps de rate limiting vivent en mémoire du process. En serverless, chaque instance cold-start repart de zéro, permettant un contournement trivial.
→ Risque faible en développement, à noter pour le déploiement (utiliser Redis/Upstash si attaque ciblée).

---

### 🟡 Points de vigilance

- **`catch {}` silencieux dans `ToolHeader.tsx:24`** — `navigator.share()` peut échouer si l'utilisateur annule ou si l'API n'est pas supportée. Le catch vide est acceptable ici (l'UX fallback clipboard est déjà géré), mais aucun log n'existe si la copie clipboard elle-même échoue (ligne 27 : pas de try/catch autour de `navigator.clipboard.writeText`).
- **`isSafeUrl` ne résout pas les DNS** — un attaquant contrôlant un DNS public pourrait faire pointer `evil.com` vers une IP privée (DNS rebinding). Mitigé en production par le réseau d'isolation de la plateforme, mais pas par le code.
- **Pas de `.gitignore` vérifié** — aucun fichier `.env` trouvé dans le projet. Confirmer que `.env.local` est bien dans `.gitignore` avant le premier push.

---

### Progression
- [x] Variables d'env sécurisées (pas de secret côté client détecté)
- [x] Server Actions protégées (pas de Server Actions dans ce projet)
- [x] API routes sécurisées (rate limiting + validation + SSRF)
- [x] Auth côté serveur (pas d'auth dans ce projet — public)
- [x] XSS protégé (pas de dangerouslySetInnerHTML avec user content)
- [x] Headers de sécurité complets (X-Frame-Options, X-Content-Type-Options, Referrer-Policy ajoutés)
- [x] checkResponseSize streaming-safe — ajout de `checkTextSize()` dans route-security.ts, appelée après `res.text()` dans /api/meta et /api/seo
