## Next.js Code Review
**Date:** 2026-06-14
**Router:** App Router
**Deployment:** Standard

---

### ✅ Points positifs

- Server Components par défaut — `'use client'` uniquement sur les composants qui en ont besoin (hooks, événements, localStorage).
- `generateStaticParams()` + `generateMetadata()` correctement implémentés pour `/t/[slug]`.
- `notFound()` appelé dans le handler de tool page (`app/t/[slug]/page.tsx:26`).
- `params: Promise<{ slug: string }>` — typage Next.js 15 correct (params asynchrones).
- `lib/route-security.ts` — utilitaires partagés, pas de duplication entre les 3 routes API.
- Providers bien structurés dans `Providers.tsx` — un seul niveau d'imbrication lisible.

---

### ⚠️ Boundary Server/Client à corriger

**`lang="fr"` hardcodé sur `<html>`** — `app/layout.tsx:32`
```tsx
<html lang="fr" ...>
```
> L'attribut `lang` ne reflète pas la langue active de l'utilisateur. Les lecteurs d'écran et les moteurs de recherche reçoivent toujours `fr` même quand l'UI est en anglais.
→ Le ThemeProvider ou I18nProvider devrait mettre à jour l'attribut `lang` via `document.documentElement.lang`, ou choisir une locale par défaut fixe et l'assumer.

**`HomeClient` sur-utilisé comme Client Component** — `components/home/HomeClient.tsx:1`
> La section Hero, FeaturedCard et CategorySection ne consomment aucun hook client. Ils sont rendus côté client à cause du `useState` sur `activeCat`.
→ Séparer : `HomeCategoryFilter` (client, petit), laisser le reste en Server Component.

---

### ⚠️ Problèmes mineurs

**Non-null assertion fragile** — `components/home/HomeClient.tsx:27`
```tsx
const featured = TOOLS.find((t) => t.slug === "json-formatter")!;
```
> Si le slug est renommé ou l'outil supprimé, crash runtime. Le `!` masque le risque.
→ Remplacer par `TOOLS.find(…) ?? TOOLS[0]` ou extraire le slug featured dans une constante nommée.

**`StatBlock` toujours importé dans CatalogPageClient** — `components/catalog/CatalogPageClient.tsx:11`
```ts
import { StatBlock } from "@/components/home/StatBlock";
```
> StatBlock est encore utilisé (ligne 89 — affiche le count de filtered), mais l'audit précédent avait mentionné sa suppression. L'import est valide mais à surveiller si StatBlock est un composant partagé ou si sa logique runs a été retirée.

**`"most used"` hardcodé en anglais** — `components/home/FeaturedCard.tsx:25`
```tsx
<div className="font-mono text-[11px] text-dim">{catLabel} · most used</div>
```
→ Ajouter une clé i18n ou passer la string en prop depuis le parent.

**Sort "new" ne fait rien** — `components/catalog/CatalogPageClient.tsx:42`
```ts
if (sort === "new") return 0;
```
→ La UI affiche une option "récent" qui trie de façon identique à "popularité" quand les runs sont ex-æquo. Soit implémenter (champ `addedAt`), soit masquer l'option.

**Descriptions hardcodées en JSX** — multiples composants
> `GenericWorkspace.tsx` (lignes 19, 24, 40, 65-68), `CatalogPageClient.tsx` (lignes 79-84), `HomeClient.tsx` (lignes 62-64, 75-77) — du texte UI bilingue inline partout au lieu de passer par le dict `i18n`.
→ Non bloquant mais crée de la dette : les nouvelles strings doivent être ajoutées dans 2 endroits si on veut les centraliser plus tard.

---

### ⚠️ App Router — Layouts / Loading / Error

- **Aucun `loading.tsx`** — aucun squelette de chargement, pas de streaming.
- **Aucun `error.tsx`** — les erreurs runtime causent une page blanche (voir audit error-handling).
- **Aucun `not-found.tsx`** — `notFound()` est appelé dans `page.tsx` mais il n'y a pas de page 404 personnalisée.
- **Aucun `global-error.tsx`** — les erreurs catastrophiques ne sont pas gérées.

---

### Progression
- [x] `'use client'` uniquement où nécessaire
- [x] Data fetching en Server Component (statique ou generateStaticParams)
- [x] API routes avec validation + status codes corrects
- [x] Pas de secrets côté client
- [x] `lang` HTML reflète la locale active (useEffect dans I18nProvider)
- [x] `error.tsx` / `not-found.tsx` définis
- [x] Non-null assertion `featured` sécurisée (`?? TOOLS[0]`)
- [x] Strings UI principales centralisées dans le dict (share, bookmark, counts, favoris, most used)
- [x] `loading.tsx` défini — app/loading.tsx (home) + app/t/[slug]/loading.tsx (tool page)
- [x] Strings inline hero et catalogue migrées vers le dict
- [ ] GenericWorkspace strings — stub temporaire, à migrer avec les vrais workspaces
