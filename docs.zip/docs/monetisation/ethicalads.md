# EthicalAds

Réseau pub privacy-first pour sites dev/tech. Pas de cookies tiers → pas de bandeau consentement RGPD.

---

## 1. Inscription

1. Aller sur **ethicalads.io** → "Become a Publisher"
2. Remplir le formulaire : URL du site, type de contenu, audience estimée
3. Décrire toolhub comme "free developer tools — JSON formatter, Base64, UUID, SEO analyzer…"
4. Validation manuelle par leur équipe — en général sous 1-5 jours ouvrés
5. Une fois accepté : accès au dashboard publisher

**Prérequis minimum** : contenu en anglais (ou bilingue), audience tech/dev, pas de contenu NSFW
**Pas de seuil de trafic officiel** — ils acceptent les petits sites si le contenu est pertinent

---

## 2. Ce que tu reçois

- **CPM** : $1 à $3 selon l'audience et la période (plus élevé Q4)
- **Paiement** : mensuel, seuil $50, via PayPal ou virement
- **Format** : 1 bloc par page, 130×100px (petit) ou texte+image
- **Dashboard** : impressions, clics, revenus, taux de remplissage
- **Pas de cookies** : ciblage par contenu de la page, pas par profil utilisateur

---

## 3. Intégration dans toolhub

### Où placer le bloc

Deux options, pas les deux en même temps :

**Option A — Dans le Footer** (une seule fois sur tout le site, discret)
Composant `components/layout/Footer.tsx` — ajouter dans une colonne ou sous les liens.

**Option B — Dans la page catalogue `/tools`** (fort trafic, bonne visibilité)
Composant `components/catalog/CatalogPageClient.tsx` — ajouter en haut de la sidebar ou sous la liste.

### Le script EthicalAds

Après acceptation, le dashboard fournit un snippet de ce type :

```html
<div
  data-ea-publisher="TON_PUBLISHER_ID"
  data-ea-type="image"
  class="ethical-ads"
/>
<script async src="https://media.ethicalads.io/media/client/ethicalads.min.js" />
```

### Composant React à créer

```tsx
// components/ads/EthicalAd.tsx
"use client";

import { useEffect } from "react";

declare global {
  interface Window { ethicalads?: { load: () => void }; }
}

export function EthicalAd({ publisherId }: { publisherId: string }) {
  useEffect(() => {
    if (window.ethicalads) window.ethicalads.load();
  }, []);

  return (
    <>
      <div
        data-ea-publisher={publisherId}
        data-ea-type="image"
        className="ethical-ads"
      />
      <script
        async
        src="https://media.ethicalads.io/media/client/ethicalads.min.js"
      />
    </>
  );
}
```

### Utilisation

```tsx
<EthicalAd publisherId="TON_PUBLISHER_ID" />
```

Remplacer `TON_PUBLISHER_ID` par l'identifiant fourni dans le dashboard après acceptation.

---

## 4. Notes

- **Pas de bandeau cookie** — EthicalAds ne pose aucun cookie publicitaire, le ciblage est contextuel (contenu de la page)
- **Adblock** — leur script est moins bloqué que AdSense car il vient d'un domaine connu pour sa déontologie, mais une partie des devs le bloquera quand même
- **Taux de remplissage** — peut être inférieur à 100% au début (ils n'ont pas toujours une pub pour chaque impression), normal
- **Carbon Ads** — une fois que toolhub a du trafic (~10k/mois), postuler à Carbon Ads pour un CPM plus élevé ; le composant à remplacer sera quasiment identique
