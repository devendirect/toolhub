# Affiliation Semrush

Outil cible : **SEO Analyzer** (`/t/seo-analyzer`)
Placement : bloc affiché après le score SEO, sous les résultats

---

## 1. Inscription

1. Aller sur **semrush.com** → section "Affiliates" ou "Partners" dans le footer
2. Le programme est géré via la plateforme **Impact** (impact.com)
3. Créer un compte Impact si tu n'en as pas
4. Soumettre une demande : décrire toolhub (outils SEO gratuits, audience dev/marketeurs)
5. Validation en général sous 1-3 jours ouvrés
6. Une fois accepté : récupérer le **lien d'affiliation unique** depuis le dashboard Impact

**Commission** : ~$200 par premier abonnement payant
**Durée du cookie** : 120 jours
**Seuil de paiement** : $50 minimum

---

## 2. Ce que tu reçois

- Lien tracké unique (ex: `https://www.semrush.com/...?ref=TONID`)
- Bannières et assets visuels disponibles dans Impact
- Dashboard temps réel : clics, conversions, revenus

---

## 3. Intégration dans toolhub

### Où
Composant `components/workspaces/SeoAnalyzer.tsx` — ajouter un bloc **après** le score ring et la checklist.

### Quoi afficher
Uniquement si un score a été généré (ne pas afficher sur l'état vide).

```tsx
{score !== null && (
  <div className="mt-6 p-4 border border-line bg-bg-1 flex items-start gap-4">
    <span className="font-mono text-[20px]">↗</span>
    <div className="flex flex-col gap-1">
      <span className="font-mono text-[11px] text-dim uppercase tracking-[0.1em]">
        {lang === "fr" ? "aller plus loin" : "go further"}
      </span>
      <p className="text-[13px] text-fg-1">
        {lang === "fr"
          ? "Analyse complète : mots-clés, backlinks, concurrents — avec Semrush."
          : "Full audit: keywords, backlinks, competitors — with Semrush."}
      </p>
      <a
        href="TON_LIEN_AFFILIATION"
        target="_blank"
        rel="noopener noreferrer"
        className="mt-1 inline-flex items-center gap-1 font-mono text-[12px] text-brand hover:underline"
      >
        Essayer Semrush gratuitement →
      </a>
    </div>
  </div>
)}
```

### Variables à remplacer
- `TON_LIEN_AFFILIATION` → le lien récupéré dans Impact après inscription

---

## 4. Notes

- Semrush offre un essai gratuit 7 jours — meilleur point d'entrée pour convertir
- Mentionner "gratuit" dans le CTA augmente le CTR
- Ne pas afficher si score = 100 (utilisateur avancé, moins susceptible de convertir)
