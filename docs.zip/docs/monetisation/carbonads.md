# Carbon Ads

Réseau pub premium pour sites dev/design. Invitation uniquement — à postuler quand toolhub a du trafic (~10k visites/mois).

---

## 1. Inscription

1. Aller sur **carbonads.net** → "Become a Publisher"
2. Remplir le formulaire : URL, catégorie (Developer Tools), description, trafic mensuel estimé
3. Décrire toolhub : "free developer toolkit — 25 tools including JSON formatter, Base64, UUID generator, SEO analyzer. Audience : developers and technical users."
4. Leur équipe visite le site manuellement et valide ou refuse
5. Délai : 1 à 3 semaines
6. Si accepté : accès au dashboard, récupération du snippet

**Prérequis réels (non officiels mais observés)**
- ~10 000 visites/mois minimum
- Contenu en anglais
- Design propre, pas de publicité intrusive déjà en place
- Audience majoritairement tech/dev

---

## 2. Ce que tu reçois

- **CPM** : $3 à $8 selon l'audience, la saisonnalité (pic en Q4) et la page
- **Format** : 1 seul bloc par page — 130×100px image + texte court. Pas de bannière, pas de pop-up.
- **1 annonceur à la fois** par page — pub beaucoup moins intrusive que les régies classiques
- **Paiement** : mensuel, seuil $50, via PayPal
- **Pas de cookies tiers** → pas de bandeau consentement RGPD nécessaire

---

## 3. Intégration dans toolhub

### Où placer le bloc

Même logique qu'EthicalAds — une seule instance par page :

**Option A — Footer** (présent sur toutes les pages, discret)
Composant `components/layout/Footer.tsx`

**Option B — Page catalogue `/tools`** (fort trafic, sidebar)
Composant `components/catalog/CatalogPageClient.tsx`

**Option C — Pages outil `/t/[slug]`** (audience qualifiée, recommandé par Carbon)
Composant `components/tool/ToolPageClient.tsx` — sous le workspace

### Le script Carbon Ads

Le dashboard fournit un snippet de ce type après acceptation :

```html
<script
  async
  type="text/javascript"
  src="//cdn.carbonads.com/carbon.js?serve=TON_CODE&placement=TON_PLACEMENT"
  id="_carbonads_js"
/>
```

### Composant React à créer

```tsx
// components/ads/CarbonAd.tsx
"use client";

import { useEffect, useRef } from "react";

interface Props {
  serve: string;
  placement: string;
}

export function CarbonAd({ serve, placement }: Props) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!ref.current || ref.current.querySelector("#_carbonads_js")) return;
    const script = document.createElement("script");
    script.src = `//cdn.carbonads.com/carbon.js?serve=${serve}&placement=${placement}`;
    script.id = "_carbonads_js";
    script.async = true;
    ref.current.appendChild(script);
  }, [serve, placement]);

  return <div ref={ref} className="carbon-wrap" />;
}
```

### Utilisation

```tsx
<CarbonAd serve="TON_CODE" placement="TON_PLACEMENT" />
```

Remplacer `TON_CODE` et `TON_PLACEMENT` par les valeurs fournies dans le dashboard Carbon après acceptation.

### Style à ajouter dans `globals.css`

Carbon injecte ses propres classes — un minimum de style pour l'intégrer proprement :

```css
.carbon-wrap {
  margin-top: 1rem;
}

#carbonads {
  display: flex;
  font-family: var(--font-mono);
  font-size: 11px;
  line-height: 1.5;
  border: 1px solid var(--line);
  background: var(--bg-1);
  padding: 12px;
  max-width: 260px;
}

#carbonads a {
  color: var(--fg-1);
  text-decoration: none;
}

#carbonads a:hover {
  color: var(--fg);
}

.carbon-img img {
  display: block;
  width: 130px;
  height: 100px;
  object-fit: cover;
  margin-bottom: 8px;
}

.carbon-text {
  display: block;
  margin-bottom: 6px;
}

.carbon-poweredby {
  display: block;
  font-size: 10px;
  color: var(--dim);
}
```

---

## 4. Migration depuis EthicalAds

Quand Carbon Ads accepte toolhub :

1. Supprimer `<EthicalAd />` des emplacements concernés
2. Remplacer par `<CarbonAd serve="..." placement="..." />`
3. Supprimer le script EthicalAds s'il n'est plus utilisé nulle part
4. Ajouter les styles `globals.css` ci-dessus

Le composant est différent mais l'emplacement dans le layout reste identique — la migration prend ~15 minutes.

---

## 5. Notes

- **1 bloc par page maximum** — Carbon le vérifie et peut désactiver le compte si la règle n'est pas respectée
- **Pas de modification du bloc** — le HTML injecté par Carbon ne doit pas être stylisé au-delà du wrapper, sauf via leurs classes officielles
- **CPM variable** — les outils dev (JSON, Base64, UUID) ont une audience très qualifiée, CPM plus élevé que la moyenne
- **Refus possible** — si Carbon refuse au premier essai, reposter la candidature 3-6 mois plus tard avec les stats de trafic mises à jour
