# Affiliation NordVPN

Outil cible : **IP Address Lookup** (`/t/ip-lookup`)
Placement : bloc affiché après le tableau de résultats (pays, ISP, ASN…)

---

## 1. Inscription

1. Aller sur **nordvpn.com** → footer → "Affiliates" ou chercher "NordVPN affiliate program"
2. Le programme est géré via **Impact** (impact.com) — même plateforme que Semrush
3. Si tu as déjà un compte Impact (créé pour Semrush), tu peux candidater directement
4. Soumettre une demande : décrire toolhub comme outil privacy/dev, mentionner l'outil IP Lookup
5. Validation rapide (souvent 24-48h, programme très ouvert)
6. Récupérer le lien tracké depuis Impact

**Commission** : 40% sur les nouveaux abonnements, 30% sur les renouvellements
**Durée du cookie** : 30 jours
**Seuil de paiement** : $10 minimum — le plus bas des 3 programmes

---

## 2. Ce que tu reçois

- Lien tracké unique via Impact
- Assets visuels et codes promo disponibles
- Dashboard Impact : clics, conversions, revenus en temps réel

---

## 3. Intégration dans toolhub

### Où
Composant `components/workspaces/IpLookup.tsx` — ajouter un bloc **sous** le tableau de résultats.

### Quoi afficher
Uniquement quand un résultat est affiché (pas sur l'état initial).

```tsx
{result && (
  <div className="mt-4 p-4 border border-line bg-bg-1 flex items-start gap-4">
    <span className="font-mono text-[20px] text-[--brand-amber]">⚠</span>
    <div className="flex flex-col gap-1">
      <span className="font-mono text-[11px] text-dim uppercase tracking-[0.1em]">
        {lang === "fr" ? "votre IP est visible" : "your IP is visible"}
      </span>
      <p className="text-[13px] text-fg-1">
        {lang === "fr"
          ? `Votre FAI (${result.isp}) et votre localisation approximative sont exposés à chaque site visité.`
          : `Your ISP (${result.isp}) and approximate location are exposed to every site you visit.`}
      </p>
      <a
        href="TON_LIEN_AFFILIATION"
        target="_blank"
        rel="noopener noreferrer"
        className="mt-1 inline-flex items-center gap-1 font-mono text-[12px] text-brand hover:underline"
      >
        {lang === "fr" ? "Masquer mon IP avec NordVPN →" : "Hide my IP with NordVPN →"}
      </a>
    </div>
  </div>
)}
```

### Variables à remplacer
- `TON_LIEN_AFFILIATION` → lien récupéré dans Impact
- `result` → adapter au nom exact de la variable d'état dans `IpLookup.tsx`
- `result.isp` → le champ ISP retourné par ip-api.com (clé : `isp`)

---

## 4. Notes

- Le hook "votre FAI est visible" est personnalisé avec le vrai nom du FAI de l'utilisateur — très impactant
- NordVPN propose souvent des codes promo (-70% sur 2 ans) — Impact les fournit, les intégrer dans le CTA augmente la conversion
- Le seuil de paiement à $10 permet de récupérer les premières commissions rapidement
- Éviter le mot "espionné" ou des formulations anxiogènes — rester factuel comme dans l'exemple ci-dessus
