# GA4 + Cookie Consent

Suivi des visites via Google Analytics 4, avec bandeau de consentement RGPD conforme.

---

## 1. Créer la propriété GA4

1. Aller sur **analytics.google.com**
2. Créer un compte si besoin → "Créer une propriété"
3. Nom de la propriété : `toolhub`
4. Fuseau horaire : Europe/Paris, devise : EUR
5. Dans "Flux de données" → "Web" → entrer l'URL du site
6. Récupérer l'**ID de mesure** (format `G-XXXXXXXXXX`) — tu en auras besoin plus bas

---

## 2. Relier à Google Search Console (recommandé)

1. Aller sur **search.google.com/search-console**
2. Ajouter une propriété → entrer l'URL du site
3. Vérifier la propriété via le fichier HTML ou la balise meta (Next.js : ajouter dans `generateMetadata` → champ `verification`)
4. Dans GA4 → Admin → "Liens Search Console" → relier les deux

Permet de voir dans GA4 quels mots-clés Google amènent du trafic.

---

## 3. Installer les dépendances

```bash
npm install react-cookie-consent
npm install @types/react-cookie-consent -D
```

> `react-cookie-consent` gère le bandeau + le stockage du choix utilisateur dans un cookie fonctionnel (exempt RGPD).

---

## 4. Composant CookieBanner

```tsx
// components/analytics/CookieBanner.tsx
"use client";

import CookieConsent, { getCookieConsentValue } from "react-cookie-consent";
import { useEffect } from "react";
import { useLang } from "@/components/providers/I18nProvider";

declare global {
  interface Window {
    gtag: (...args: unknown[]) => void;
    dataLayer: unknown[];
  }
}

const GA_ID = process.env.NEXT_PUBLIC_GA_ID!;

function loadGA() {
  if (!GA_ID || document.getElementById("ga-script")) return;
  const script = document.createElement("script");
  script.id = "ga-script";
  script.src = `https://www.googletagmanager.com/gtag/js?id=${GA_ID}`;
  script.async = true;
  document.head.appendChild(script);
  window.dataLayer = window.dataLayer || [];
  window.gtag = function (...args) { window.dataLayer.push(args); };
  window.gtag("js", new Date());
  window.gtag("config", GA_ID, { anonymize_ip: true });
}

export function CookieBanner() {
  const { lang } = useLang();

  useEffect(() => {
    if (getCookieConsentValue("toolhub-consent") === "true") loadGA();
  }, []);

  return (
    <CookieConsent
      cookieName="toolhub-consent"
      onAccept={loadGA}
      onDecline={() => {}}
      enableDeclineButton
      buttonText={lang === "fr" ? "Accepter" : "Accept"}
      declineButtonText={lang === "fr" ? "Refuser" : "Decline"}
      style={{
        background: "var(--bg-1)",
        borderTop: "1px solid var(--line)",
        fontFamily: "var(--font-mono)",
        fontSize: "12px",
        color: "var(--fg-1)",
        alignItems: "center",
        padding: "12px 24px",
      }}
      buttonStyle={{
        background: "var(--brand)",
        color: "var(--bg)",
        fontFamily: "var(--font-mono)",
        fontSize: "12px",
        fontWeight: "600",
        borderRadius: "3px",
        padding: "6px 16px",
        margin: "0 8px 0 0",
      }}
      declineButtonStyle={{
        background: "transparent",
        color: "var(--dim)",
        fontFamily: "var(--font-mono)",
        fontSize: "12px",
        border: "1px solid var(--line-2)",
        borderRadius: "3px",
        padding: "6px 16px",
        margin: "0",
      }}
    >
      {lang === "fr"
        ? "Ce site utilise Google Analytics pour mesurer l'audience. Vos données sont anonymisées."
        : "This site uses Google Analytics to measure traffic. Your data is anonymized."}
    </CookieConsent>
  );
}
```

---

## 5. Variable d'environnement

Créer `.env.local` à la racine (ne pas committer) :

```
NEXT_PUBLIC_GA_ID=G-XXXXXXXXXX
```

Remplacer `G-XXXXXXXXXX` par l'ID de mesure récupéré à l'étape 1.

Ajouter `.env.local` dans `.gitignore` si ce n'est pas déjà le cas.

---

## 6. Ajouter le bandeau dans l'app

Dans `components/providers/Providers.tsx`, ajouter `<CookieBanner />` :

```tsx
import { CookieBanner } from "@/components/analytics/CookieBanner";

export function Providers({ children }: { children: ReactNode }) {
  return (
    <ThemeProvider>
      <I18nProvider>
        <PaletteProvider>
          {children}
          <Toaster />
          <CookieBanner />
        </PaletteProvider>
      </I18nProvider>
    </ThemeProvider>
  );
}
```

---

## 7. Mettre à jour le ROADMAP

Réactiver la note sur la gestion cookies dans le ROADMAP — GA4 pose des cookies, le bandeau est obligatoire pour l'UE.

---

## 8. Conformité RGPD — checklist

- [x] GA ne se charge **que** si l'utilisateur accepte
- [x] `anonymize_ip: true` activé — les IPs sont tronquées côté Google
- [x] Choix mémorisé dans un cookie fonctionnel (`toolhub-consent`) — exempt RGPD
- [x] Bouton "Refuser" présent — obligatoire, le refus doit être aussi simple que l'acceptation
- [ ] Ajouter un lien "Politique de confidentialité" dans le Footer (recommandé, pas obligatoire pour un site sans inscription)
- [ ] Ajouter dans le Footer un lien "Gérer les cookies" qui rouvre le bandeau (optionnel mais bonne pratique)

---

## 9. Rouvrir le bandeau depuis le Footer (optionnel)

Pour permettre à l'utilisateur de changer son choix :

```tsx
// Dans Footer.tsx
import { resetCookieConsentValue } from "react-cookie-consent";

<button
  onClick={() => { resetCookieConsentValue("toolhub-consent"); window.location.reload(); }}
  className="font-mono text-[11px] text-dim hover:text-fg-1 transition-colors"
>
  {lang === "fr" ? "Gérer les cookies" : "Manage cookies"}
</button>
```

---

## 10. Notes

- **GA4 en production uniquement** — `NEXT_PUBLIC_GA_ID` sera absent en dev local, `loadGA()` s'arrête silencieusement grâce au `if (!GA_ID)` 
- **Adblock** — une partie des devs bloque GA4, les stats seront sous-estimées d'environ 20-30% sur cette audience. C'est inévitable sans solution payante.
- **Retention des données** — dans GA4 → Admin → "Contrôles des données" → passer la rétention à 14 mois (défaut : 2 mois)
- **Search Console** — vérifier le site dès le départ même avant d'avoir du trafic, Google commence à indexer et collecter des données immédiatement

---

## 11. GA4 Custom Events — Suivi des exécutions d'outils

### Objectif

Remplacer les valeurs `runs` hardcodées dans `lib/tools.ts` par des données réelles issues de GA4. Chaque fois qu'un utilisateur lance un outil, un événement est envoyé à GA4 — ce qui permet de connaître le vrai nombre d'exécutions par outil.

> **Condition préalable** : GA4 ne se charge que si l'utilisateur a accepté les cookies (voir `CookieBanner` section 4). Les événements ne sont donc pas envoyés pour les utilisateurs qui refusent ou n'ont pas encore choisi.

---

### Structure de l'événement

```ts
gtag("event", "tool_run", {
  tool_slug:     "json-formatter",  // slug de lib/tools.ts
  tool_category: "text",            // cat de lib/tools.ts
});
```

Paramètres :
- `tool_slug` — identifiant unique de l'outil (déjà utilisé dans les URLs `/t/[slug]`)
- `tool_category` — catégorie (`file`, `dev`, `text`, `design`, `seo`) pour filtrer par groupe

---

### Où placer l'appel dans le code

**Option A — Dans chaque workspace** (précis, au moment exact où l'outil tourne) :

```tsx
// Exemple dans JsonFormatter.tsx
const handleRun = () => {
  // ... logique de l'outil ...

  if (typeof window !== "undefined" && typeof window.gtag === "function") {
    window.gtag("event", "tool_run", {
      tool_slug:     "json-formatter",
      tool_category: "text",
    });
  }
};
```

**Option B — Hook partagé `useTrackRun`** (recommandé pour éviter la répétition) :

```ts
// hooks/useTrackRun.ts
export function useTrackRun(slug: string, category: string) {
  return () => {
    if (typeof window !== "undefined" && typeof window.gtag === "function") {
      window.gtag("event", "tool_run", { tool_slug: slug, tool_category: category });
    }
  };
}

// Dans un workspace :
const trackRun = useTrackRun("json-formatter", "text");
// Appeler trackRun() au moment du clic "run" ou de la transformation
```

> `window.gtag` est défini par le script GA4 chargé dans `loadGA()`. Le guard `typeof window.gtag === "function"` évite les erreurs en SSR et quand GA4 n'est pas chargé (refus cookies ou dev local).

---

### Déclarer le type `gtag` dans TypeScript

Pour éviter les erreurs TypeScript sur `window.gtag` :

```ts
// types/gtag.d.ts  (créer ce fichier)
interface Window {
  gtag: (command: string, action: string, params?: Record<string, string>) => void;
}
```

---

### Consulter les données dans GA4

1. Aller dans **GA4 → Rapports → Événements**
2. Cliquer sur l'événement `tool_run`
3. Dans le tableau de bord de l'événement, ajouter la dimension **`tool_slug`** pour voir la répartition par outil
4. La colonne **"Nombre d'événements"** donne le total d'exécutions par outil

Pour un rapport plus avancé : **GA4 → Explorer → Exploration de forme libre** :
- Dimensions : `tool_slug`, `tool_category`
- Métriques : `Nombre d'événements`, `Utilisateurs actifs`
- Filtre : `Nom d'événement == tool_run`

---

### Mettre à jour `lib/tools.ts` avec les vraies données

Les `runs` dans `lib/tools.ts` sont actuellement des valeurs fictives. Pour les mettre à jour périodiquement :

**Méthode manuelle** (suffisante au départ) :
1. Dans GA4 → Explorer, créer un rapport `tool_run` par `tool_slug`
2. Exporter en CSV
3. Mettre à jour les valeurs `runs` dans `lib/tools.ts` à la main

**Méthode automatisée** (quand le trafic justifie l'effort) :
- Utiliser la **GA4 Data API** (anciennement Reporting API v4) avec un script Node.js
- Authentification via un compte de service Google (JSON key)
- Endpoint : `POST https://analyticsdata.googleapis.com/v1beta/properties/{GA4_ID}:runReport`
- Payload : `{ dimensions: [{name: "customEvent:tool_slug"}], metrics: [{name: "eventCount"}], dateRanges: [{startDate: "2020-01-01", endDate: "today"}] }`
- Le script écrit les résultats dans `lib/tools.ts` ou un fichier JSON séparé importé par `lib/tools.ts`

> La GA4 Data API a une latence de ~24h — les données du jour ne sont pas disponibles en temps réel.

---

### Note sur la précision des compteurs

- Les utilisateurs sans consentement cookies ne sont **pas** comptés
- Les utilisateurs avec un adblocker ne sont **pas** comptés (~20-30% des devs)
- GA4 agrège par défaut toutes les sessions (sans déduplication stricte par IP)
- Les valeurs affichées dans l'UI sont donc des **ordres de grandeur**, pas des chiffres exacts — c'est suffisant pour montrer la popularité relative des outils
