# Affiliation 1Password

Outil cible : **Password Generator** (`/t/password-generator`)
Placement : bloc affiché sous le mot de passe généré

---

## 1. Inscription

1. Aller sur **1password.com** → footer → "Affiliates" ou chercher "1Password affiliate program"
2. Le programme est géré via **ShareASale** (shareasale.com)
3. Créer un compte ShareASale éditeur si tu n'en as pas
4. Chercher "1Password" dans le marketplace ShareASale et faire une demande
5. Validation en quelques jours — décrire toolhub comme outil dev/sécurité
6. Une fois accepté : générer le lien tracké depuis le dashboard ShareASale

**Commission** : ~25% sur le premier achat (individuel ou famille)
**Durée du cookie** : 45 jours
**Seuil de paiement** : $50 minimum via ShareASale

---

## 2. Ce que tu reçois

- Lien tracké unique via ShareASale
- Bannières et textes pré-rédigés disponibles
- Dashboard ShareASale : clics, EPC (earnings per click), commissions

---

## 3. Intégration dans toolhub

### Où
Composant `components/workspaces/PasswordGenerator.tsx` — ajouter un bloc **sous** la liste des mots de passe générés.

### Quoi afficher
Toujours visible dès qu'un mot de passe est généré (le besoin de stockage est immédiat).

```tsx
{passwords.length > 0 && (
  <div className="mt-4 p-4 border border-line bg-bg-1 flex items-start gap-4">
    <span className="font-mono text-[20px]">🔑</span>
    <div className="flex flex-col gap-1">
      <span className="font-mono text-[11px] text-dim uppercase tracking-[0.1em]">
        {lang === "fr" ? "stocker en sécurité" : "store it safely"}
      </span>
      <p className="text-[13px] text-fg-1">
        {lang === "fr"
          ? "Un bon mot de passe ne sert à rien s'il est perdu. Stocke-le avec 1Password."
          : "A strong password means nothing if you lose it. Store it with 1Password."}
      </p>
      <a
        href="TON_LIEN_AFFILIATION"
        target="_blank"
        rel="noopener noreferrer"
        className="mt-1 inline-flex items-center gap-1 font-mono text-[12px] text-brand hover:underline"
      >
        {lang === "fr" ? "Essayer 1Password →" : "Try 1Password →"}
      </a>
    </div>
  </div>
)}
```

### Variables à remplacer
- `TON_LIEN_AFFILIATION` → lien généré depuis ShareASale
- `passwords.length > 0` → adapter au nom exact de la variable d'état dans le composant

---

## 4. Notes

- 1Password propose un essai gratuit 14 jours — bon argument dans le CTA
- Le message "un bon mot de passe ne sert à rien sans stockage sécurisé" est le hook naturel
- Bitwarden (gratuit, open source) est une alternative mais n'a pas de programme d'affiliation — 1Password reste le choix le plus cohérent commercialement
