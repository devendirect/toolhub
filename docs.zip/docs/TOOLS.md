# Comment fonctionnent les outils

Ce fichier détaille le fonctionnement technique de chaque outil : logique, librairies, décisions de code.  
Mis à jour à chaque nouveau workspace implémenté.

Légende : ✅ Implémenté · 🔲 À faire

---

## Fichiers

### ✅ Image Converter
**Fichier :** `components/workspaces/ImageConverter.tsx`  
**Lib :** aucune — API navigateur uniquement  
**Privacy :** `local`

**Fonctionnement :**
1. L'utilisateur dépose ou sélectionne une image (`<input type="file" accept="image/*">`)
2. Un `URL.createObjectURL()` génère une URL locale pour l'aperçu (jamais uploadé)
3. Au clic "convert", une balise `<img>` est créée en mémoire et chargée avec l'URL locale
4. L'image est dessinée sur un `<canvas>` en mémoire via `ctx.drawImage(img, 0, 0)`
5. `canvas.toBlob(callback, mimeType, quality)` produit le fichier converti
6. Un second `URL.createObjectURL()` affiche le résultat + bouton télécharger

**Décisions notables :**
- Pour JPEG, le canvas est d'abord rempli en blanc (`fillRect` blanc) avant de dessiner l'image — évite le fond noir sur les PNG transparents convertis en JPG
- Le ratio de compression (ex: `-34%`) est calculé en comparant `file.size` (original) et `blob.size` (converti)
- AVIF non proposé : `canvas.toBlob('image/avif')` est limité à Chrome 94+ et silencieusement ignoré sur les autres navigateurs

---

### ✅ PDF Merge
**Fichier :** `components/workspaces/PdfMerge.tsx`  
**Lib :** `pdf-lib`  
**Privacy :** `local`

**Fonctionnement :**
1. L'utilisateur sélectionne plusieurs fichiers `.pdf` (drag & drop ou picker)
2. À l'ajout, chaque fichier est chargé via `file.arrayBuffer()` dans `pdf-lib` pour lire le nombre de pages — affichage immédiat dans la liste
3. L'utilisateur peut réordonner les fichiers (↑↓) et en supprimer
4. Au clic "merge" : `PDFDocument.create()` crée un document vide, puis `copyPages()` copie toutes les pages de chaque source dans l'ordre affiché
5. `merged.save()` retourne un `Uint8Array`, converti en `Blob` puis téléchargé via `<a>.click()`

**Décisions notables :**
- `pdf-lib` est importé en **lazy-load** (`await import('pdf-lib')`) — le bundle (~400 Ko) ne se charge qu'au premier ajout de fichier
- Même chose pour la fusion : import dynamique au clic "merge"
- `bytes.buffer as ArrayBuffer` : le cast est nécessaire car TypeScript type le buffer de `Uint8Array` comme `ArrayBufferLike` (qui inclut `SharedArrayBuffer`), incompatible avec `BlobPart`
- Les fichiers ne transitent jamais par un serveur — `arrayBuffer()` les lit directement en mémoire locale

---

### 🔲 PDF Converter
**Lib prévue :** `pdf-lib` + `pdfjs-dist`  
`pdf-lib` pour créer/modifier des PDF, `pdfjs-dist` pour rendre les pages en images (canvas → PNG/JPG).  
La conversion PDF→Word a une fidélité médiocre sans serveur — elle sera honnêtement documentée dans l'UI.

---

### 🔲 Audio Converter
**Lib prévue :** `@ffmpeg/ffmpeg` + `@ffmpeg/util` (~25 Mo WASM)  
Lazy-load obligatoire avec indicateur de chargement. Le WASM tourne dans un Web Worker pour ne pas bloquer l'UI.

---

### 🔲 Video Converter
**Lib prévue :** même bundle `@ffmpeg/ffmpeg` que Audio — partagé entre les deux outils.

---

## Développeur

### ✅ QR Generator
**Fichier :** `components/workspaces/QrGenerator.tsx`  
**Lib :** `qrcode`  
**Privacy :** `local`

**Fonctionnement :**
1. L'utilisateur tape du texte (URL, texte brut, vCard…)
2. À chaque frappe, un `useEffect` annulable (flag `cancelled`) appelle la lib en **lazy-load** (`await import('qrcode')`)
3. Format SVG : `QRCode.toString(text, { type: 'svg' })` → string SVG injecté via `dangerouslySetInnerHTML`
4. Format PNG : `QRCode.toDataURL(text)` → data URL passée à `<img src>`
5. Téléchargement SVG : `Blob` de type `image/svg+xml` + `URL.createObjectURL`
6. Téléchargement PNG : la data URL est directement mise dans `<a href>`

**Décisions notables :**
- `dangerouslySetInnerHTML` est sûr ici car le SVG est généré entièrement par notre code, pas par une entrée utilisateur brute
- L'effet est annulable (flag `cancelled`) pour éviter les race conditions si l'utilisateur tape vite
- `qrcode` est en lazy-load : le bundle ne se charge qu'à la première utilisation de la page
- Les niveaux de correction d'erreur : L (7%), M (15%), Q (25%), H (30%) de données récupérables si le QR est partiellement abîmé

---

### ✅ Base64 Encoder / Decoder
**Fichier :** `components/workspaces/Base64Tool.tsx`  
**Lib :** aucune — API navigateur uniquement  
**Privacy :** `local`

**Fonctionnement :**
- **Encodage** : `TextEncoder().encode(str)` → `Uint8Array` → conversion octet par octet en chaîne binaire → `btoa()`
- **Décodage** : `atob(str)` → chaîne binaire → `Uint8Array` → `TextDecoder().decode()`

**Pourquoi ne pas utiliser `btoa(str)` directement ?**  
`btoa()` plante sur les caractères non-ASCII (accents, emojis, CJK…). Le passage par `TextEncoder` → binaire garantit le support UTF-8 complet.

**Décisions notables :**
- Le bouton "swap ⇄" inverse le mode ET remplace l'input par l'output — permet d'encoder puis décoder en un clic
- La conversion est dans un `useMemo` : recalcul instantané à chaque frappe, pas besoin de bouton "convertir"
- Erreur de décodage affichée inline si la chaîne base64 est invalide (`atob` lève une exception)

---

### ✅ Hash Generator
**Fichier :** `components/workspaces/HashGenerator.tsx`  
**Lib :** `spark-md5` (MD5) + `crypto.subtle` natif (SHA)  
**Privacy :** `local`

Affiche les 4 hashes simultanément. Source : textarea (texte) ou fichier (drag & drop). Pour le texte : `TextEncoder().encode(str).buffer` → `ArrayBuffer`. Pour le fichier : `file.arrayBuffer()`. SHA-1/256/512 via `crypto.subtle.digest()` → `Uint8Array` → hex. MD5 via `spark-md5` en lazy-load (`await import('spark-md5')`) — Web Crypto ne supporte pas MD5 car jugé trop faible cryptographiquement. Debounce 150ms sur le texte pour éviter de recalculer à chaque frappe. Clic sur une ligne = copie du hash.

### ✅ Markdown → HTML
**Fichier :** `components/workspaces/MarkdownHtml.tsx`  
**Lib :** `marked`  
**Privacy :** `local`

`marked.parse(input)` → HTML string, synchrone. Import via `require('marked')` dans `useMemo` (évite les problèmes SSR). Vue toggle : **preview** (rendu HTML via `dangerouslySetInnerHTML` — sûr car contenu de l'utilisateur lui-même) ou **raw HTML** (code source dans `<pre>`). Styles prose custom dans `globals.css` (`.prose-toolhub`) : titres, listes, code, blockquotes, tableaux, tout aux tokens design du projet. Téléchargement en `.html`.

### ✅ Gradient Generator
**Fichier :** `components/workspaces/GradientGenerator.tsx`  
**Lib :** aucune — CSS pur  
**Privacy :** `local`

3 types : `linear-gradient(angle, ...)`, `radial-gradient(circle, ...)`, `conic-gradient(from angle, ...)`. 2 à 5 stops : chaque stop a un `<input type="color">` + slider + champ numérique pour la position (%). Bouton "add stop" insère un nouveau stop à mi-chemin entre les deux derniers. Preview live : `style={{ background: gradient }}` sur un `<div>`. Output CSS affiché en bas, cliquable pour copier la valeur, bouton "copy CSS" pour copier `background: ...;`. Angle via slider + input numérique synchronisés.  
`crypto.subtle.digest('SHA-256', buffer)` pour SHA-1/256/512. MD5 n'est pas supporté par Web Crypto (trop faible cryptographiquement) — `spark-md5` comble ce manque pour les cas d'usage legacy/vérification de fichiers.

### ✅ Regex Tester
**Fichier :** `components/workspaces/RegexTester.tsx`  
**Lib :** aucune — `RegExp` natif JS  
**Privacy :** `local`

Le pattern et le texte sont analysés via `new RegExp(pattern, flags)` + `text.matchAll(regex)`. Le flag `g` est toujours forcé pour `matchAll`. Les autres flags (`i`, `m`, `s`) sont toggleables. Le résultat est découpé en segments alternés (non-match / match) rendus comme `<span>` / `<mark>`. Les groupes capturés `(...)` sont affichés dans la liste des matches. 4 exemples rapides (email, URL, hex, date). Protection contre les zero-length matches (évite la boucle infinie).

---

### ✅ IP Lookup
**Fichier :** `components/workspaces/IpLookup.tsx` · Route Handler : `app/api/ip/route.ts`  
**Lib :** aucune — `ip-api.com` (API externe gratuite)  
**Privacy :** `network`

Route Handler `GET /api/ip?ip=` → si `?ip=` absent, utilise `x-forwarded-for` pour retourner l'IP du visiteur. Appel `http://ip-api.com/json/{ip}?fields=...` côté serveur (HTTP obligatoire sur le plan gratuit). Timeout 8s avec `AbortController`. Résultat : pays, région, ville, ZIP, lat/lon, timezone, ISP, organisation, AS. Clic sur chaque ligne = copie dans le presse-papier. Lien "voir sur la carte" → OpenStreetMap avec les coordonnées. Emoji drapeau généré via `codePointAt + 127397` (régional indicator symbols).

---

### ✅ UUID Generator
**Fichier :** `components/workspaces/UuidGenerator.tsx`  
**Lib :** aucune — `crypto.randomUUID()` natif  
**Privacy :** `local`

Génère 1 à 25 UUID v4 en un clic. Chaque UUID est cliquable (copie individuelle), bouton "copier tout" pour la liste complète. La génération est via `crypto.randomUUID()` — cryptographiquement sécurisé, natif dans tous les navigateurs modernes. Affichage : numéro de ligne, UUID, "copier" au survol.

---

### ✅ Cron Generator
**Fichier :** `components/workspaces/CronGenerator.tsx`  
**Lib :** `cronstrue` (lazy-load)  
**Privacy :** `local`

5 champs éditables (minute / heure / jour du mois / mois / jour de la semaine) avec presets rapides par champ (`*`, `*/5`, `1-5`…). 7 presets globaux (every minute, daily, weekdays, weekly…). L'expression est assemblée en `${min} ${hour} ${dom} ${mon} ${dow}`. `cronstrue.toString(expr, { locale: 'fr' })` est appelé en lazy-load à chaque changement → description en langage naturel. Tableau de référence de la syntaxe (`*`, `,`, `-`, `*/n`, `L`) en bas de page.

---

## Texte

### ✅ JSON Formatter
**Fichier :** `components/workspaces/JsonFormatter.tsx`  
**Lib :** `@uiw/react-codemirror` + `@codemirror/lang-json` (éditeur), aucune pour la logique  
**Privacy :** `local`

**Fonctionnement :**
1. `JSON.parse(input)` valide et parse le JSON
2. Si `sortKeys` : `sortDeep()` trie récursivement toutes les clés d'objets par ordre alphabétique (y compris dans les objets imbriqués et les tableaux d'objets)
3. `JSON.stringify(val, null, indent)` reformate avec l'indentation choisie (2/4/8 espaces ou tab)
4. Si `minify` : `JSON.stringify(val)` sans indentation
5. Tout est dans un `useMemo` — recalcul instantané, aucun bouton "valider" nécessaire

**Décisions notables :**
- `sortDeep` est récursif : il descend dans les tableaux aussi (pour trier les objets à l'intérieur des tableaux)
- `countKeys` compte récursivement toutes les clés de l'arbre JSON pour l'affichage dans le footer
- L'éditeur CodeMirror a un thème custom `toolhubTheme` avec `{ dark: true }` — sans ce flag, CodeMirror utilise sa base light (fond blanc)
- Le token `.cm-scroller` est aussi forcé en `var(--bg-code)` pour couvrir la zone sous le contenu

---

### ✅ Case Converter
**Fichier :** `components/workspaces/CaseConverter.tsx`  
**Lib :** aucune — string JS pure  
**Privacy :** `local`

`splitWords()` normalise d'abord l'entrée en mots : détecte les transitions camelCase (`[a-z][A-Z]`), remplace `_` et `-` par des espaces. Ensuite chaque mode recompose : UPPER/lower via `.toUpperCase/toLowerCase()`, Title via capitalisation du premier caractère, camel/pascal/snake/kebab via jointure avec le séparateur approprié. Conversion en `useMemo` — instantanée à chaque frappe.

---

### ✅ Word Counter
**Fichier :** `components/workspaces/WordCounter.tsx`  
**Lib :** `Intl.Segmenter` (natif) avec fallback `.split(/\s+/)`  
**Privacy :** `local`

`Intl.Segmenter` avec `{ granularity: 'word' }` segmente correctement le texte multi-langue — filtre `.isWordLike` pour exclure les espaces et ponctuations du décompte. Fallback sur `.split(/\s+/)` si le navigateur ne supporte pas Segmenter. Stats : mots, caractères, caractères sans espaces, phrases (`.` `!` `?`), paragraphes (`\n\n`), temps de lecture estimé à 238 mots/min. Pas de bouton — tout se calcule en `useMemo` à chaque frappe.

---

### ✅ Remove Line Breaks
**Fichier :** `components/workspaces/RemoveLineBreaks.tsx`  
**Lib :** aucune — regex JS  
**Privacy :** `local`

3 modes : **space** (remplace chaque `\n` par un espace, dédoublonne les espaces), **remove** (supprime tous les `\n` sans remplacement), **normalize** (préserve les doubles sauts de paragraphe, remplace les simples `\n` par un espace). Résultat en `useMemo`, instantané.

---

### ✅ Text Reverser
**Fichier :** `components/workspaces/TextReverser.tsx`  
**Lib :** aucune  
**Privacy :** `local`

3 modes : **chars** (`Array.from(str).reverse()` — `Array.from` gère correctement les emojis et paires de substitution Unicode, contrairement à `str.split('')`), **words** (inverse l'ordre des mots sur chaque ligne), **lines** (inverse l'ordre des lignes). Résultat en `useMemo`.

---

### ✅ URL Encoder / Decoder
**Fichier :** `components/workspaces/UrlEncoder.tsx`  
**Lib :** aucune — API navigateur  
**Privacy :** `local`

`encodeURIComponent` encode tout sauf `A-Z a-z 0-9 - _ . ! ~ * ' ( )`. `decodeURIComponent` fait l'inverse. Bouton "swap ⇄" bascule le mode et place l'output en input. Erreur affichée si la chaîne encodée est malformée (ex: `%GG`). Résultat en `useMemo`.

---

### ✅ HTML Entities
**Fichier :** `components/workspaces/HtmlEntities.tsx`  
**Lib :** aucune — API navigateur (trick DOM)  
**Privacy :** `local`

**Encodage :** `textarea.textContent = str` puis `textarea.innerHTML` — le navigateur encode lui-même `<`, `>`, `&`, `"` en entités. **Décodage :** `textarea.innerHTML = str` puis `textarea.value` — le navigateur décode toutes les entités nommées (`&amp;`, `&eacute;`, `&mdash;`…) et numériques (`&#233;`). Cette approche couvre l'intégralité du standard HTML sans aucune lib. Vérifié côté client uniquement (guard `typeof document === 'undefined'` pour le SSR).

---

## Design

### ✅ Color Palette Generator
**Fichier :** `components/workspaces/PaletteGenerator.tsx`  
**Lib :** aucune — math HSL pure (sans `chroma-js`)  
**Privacy :** `local`

**Fonctionnement :**
1. L'utilisateur choisit une couleur de base via `<input type="color">` ou en tapant un hex
2. La couleur est convertie de HEX → HSL (`hexToHsl`)
3. Selon le mode d'harmonie, des angles sont appliqués à la teinte (H) :
   - Analogous : `[0, +30°, -30°, +60°, -60°]`
   - Complementary : `[0, 180°]`
   - Triadic : `[0, 120°, 240°]`
   - Split-complementary : `[0, 150°, 210°]`
   - Tetradic : `[0, 90°, 180°, 270°]`
4. Chaque couleur résultante est reconvertie HSL → HEX (`hslToHex`), et RGB calculé pour l'affichage
5. La couleur du texte sur chaque swatch est choisie via luminance (`0.299R + 0.587G + 0.114B`) — noir si luminance > 140, blanc sinon

**Pourquoi pas `chroma-js` ?**  
Les harmonies HSL de base ne nécessitent pas de lib. `chroma-js` serait utile pour des palettes perceptuellement uniformes (espace OKLCH) ou des fonctions avancées (contraste WCAG, interpolation). Ajout prévu si besoin.

**Décisions notables :**
- `((h % 360) + 360) % 360` : normalise les angles négatifs (ex: `-30°` → `330°`)
- Clic sur une valeur hex/hsl/rgb → copie dans le presse-papier + feedback visuel temporaire "✓"
- Export CSS : génère un bloc `:root { --color-1: #...; }` copié dans le presse-papier

---

### ✅ Password Generator
**Fichier :** `components/workspaces/PasswordGenerator.tsx`  
**Lib :** aucune — `crypto.getRandomValues()` natif  
**Privacy :** `local`

`crypto.getRandomValues(Uint32Array)` remplit un tableau d'entiers aléatoires cryptographiquement sécurisés. Chaque entier est réduit modulo la taille du charset (`n % charset.length`) — pas de `Math.random()`. Options : longueur (8/12/16/24/32), majuscules, chiffres, symboles, exclusion des caractères ambigus (`l`, `1`, `I`, `O`, `0`, `B`, `8`). 5 mots de passe générés simultanément. **Entropie** calculée en bits : `length × log2(pool_size)` — affiché avec label faible/moyen/fort/très fort. Clic sur une ligne = copie individuelle.

---

## SEO / Marketing

### ✅ Meta Tag Preview
**Fichier :** `components/workspaces/MetaPreview.tsx` · Route Handler : `app/api/meta/route.ts`  
**Lib :** `cheerio` (côté serveur)  
**Privacy :** `network`

Route Handler `GET /api/meta?url=` → fetch du HTML côté serveur avec User-Agent bot → parse avec `cheerio` → extraction de `<title>`, `description`, `og:*`, `twitter:*`, `canonical`, `robots`, `favicon`. Timeout 10s. 3 onglets de prévisualisation : **Google SERP** (favicon + nom de domaine + titre bleu + description grise, max 65/165 chars), **Facebook OG** (image + fond #f2f3f5 + titre + description), **Twitter/X** (image arrondie + titre + texte). Tableau "raw tags" des métadonnées trouvées. Longueur tronquée proprement avec `…`.

---

### ✅ SEO Analyzer
**Fichier :** `components/workspaces/SeoAnalyzer.tsx` · Route Handler : `app/api/seo/route.ts`  
**Lib :** `cheerio` (côté serveur)  
**Privacy :** `network`

Route Handler `GET /api/seo?url=` → fetch + parse cheerio. 11 vérifications pondérées (score sur 96 pts) : title (30-65 chars), meta description (100-165 chars), unicité H1, structure Hn, longueur de contenu (300+ mots), images avec alt, canonical, robots (noindex = échec), Open Graph, Twitter Card, liens. Score global en % arrondi. Affichage : anneau SVG coloré (vert ≥80, orange ≥50, rouge <50) + compteurs pass/warn/fail + liste de checks avec barre de points. Interface type : `SeoCheck` exportée depuis le Route Handler et importée par le workspace pour le typage.
