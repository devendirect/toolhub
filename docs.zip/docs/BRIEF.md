# toolhub — Brief de développement (handoff)

> Spec à destination d'un agent de code (Claude Code) pour démarrer l'implémentation React.
> Le prototype de référence visuelle est `toolhub.html` (à la racine du projet design).
> **Le nom "toolhub" est provisoire** (WebbyTools était pris) — un rebrand est à prévoir, donc centralise le nom de marque dans une seule constante.

---

## 1. Le produit

Une **boîte à outils web tout-en-un** : ~25 micro-outils gratuits, accessibles depuis le navigateur, **sans inscription**.

Catégories :
- **Fichiers** — Image converter, PDF converter, Audio converter, Video converter, PDF merge
- **Développeur** — QR generator, Base64, Markdown→HTML, Hash (MD5/SHA), Regex tester, IP lookup, UUID, Cron generator
- **Texte** — JSON formatter, Case converter, Word counter, Remove line breaks, Text reverser, URL encoder, HTML entities
- **Design** — Palette generator, Password generator, Gradient generator
- **Marketing/SEO** — Meta tag preview, SEO analyzer

**Proposition de valeur** : rapide, instantané, privé. La majorité des outils tournent **100 % dans le navigateur** (aucun upload, aucun log). Une intention → un résultat, sans friction.

**Audience** : équilibrée développeurs / designers / grand public. Le ton doit parler aux techniciens sans intimider les non-techniciens.

**Personnalité** : tech / *developer-first*, **esthétique terminal** (monospace, fond très sombre, prompts shell `~/ $ …`, curseur clignotant, "icônes" en box-drawing ASCII, filets 1px, grille de points en fond). Sérieux avec une pointe de caractère.

**Bilingue FR/EN** avec switcher (l'UI entière est traduite).

---

## 2. Décision de stack

**shadcn/ui + Tailwind — NE PAS partir de zéro.**

Raison : shadcn n'est pas une lib de style imposé, c'est du code que **tu possèdes** (primitives Radix + cmdk) collé dans le repo et restylé à 100 %. Tu gardes l'esthétique terminal *et* tu récupères l'accessibilité (focus-trap, navigation clavier, ARIA, scroll) sur les briques pénibles. Le `<Command>` (cmdk) justifie à lui seul le choix : c'est le moteur de la palette ⌘K.

**Règle** : shadcn pour les primitives, **wrappers maison fins** pour tout ce qui porte la signature de marque.

### Stack technique
- **Next.js (App Router) + TypeScript**
- **Tailwind CSS** + **shadcn/ui**
- Tokens de design (voir §5 + `tokens.css`) injectés dans `tailwind.config` ; thème dynamique via CSS variables (permet les Tweaks : accent / densité / police)
- Polices : **Geist** + **Geist Mono** (UI) et **JetBrains Mono** (data/commandes) via `next/font`
- i18n léger (dictionnaire FR/EN + provider), pas besoin d'i18next pour commencer

### Routing
- `/` — home (sections par catégorie)
- `/tools` — catalogue complet (sidebar + liste)
- `/tools/[category]` — catégorie filtrée
- `/t/[slug]` — page outil + workspace

---

## 3. Liste des composants

### A. Primitives (depuis shadcn, puis restylées aux tokens)
`Button` · `Input` · `Textarea` · `Switch` · `Slider` · `ToggleGroup` (segmented: indent, format, densité) · `Tabs` (encode/decode) · `Select` / `DropdownMenu` (tri, langue) · **`Command`** (⌘K) · `Dialog` (overlay palette + modales) · `Tooltip` · `Badge` · `ScrollArea` · `Sonner` (toast "copié !") · `Separator`

### B. Wrappers de marque (maison, très fins)
`Mono` / `Dim` (helpers texte) · `Cursor` (curseur clignotant) · `PromptBar` (`~/ $ …`) · `TerminalFrame` (coins ┌┐└┘) · `SectionHead` (`// label` + filet + action) · `StatBlock` · `LogoMark` (SVG, grille 2×2) · `Tag` · `Kbd`

### C. App shell
`AppShell` (fond grille + scanline) · `Header` (nav, switch langue, trigger ⌘K, statut "operational") · `Footer` · `I18nProvider` · `ThemeProvider` (accent / densité / police) + routing (§2)

### D. Composants métier
`CommandPalette` (cmdk + catalogue + groupes "populaires" / par catégorie, nav clavier ↑↓⏎, esc) · `ToolCard` (badge "● live" si workspace dédié) · `CategorySection` · `CategoryChips` · `FeaturedCard` · `ToolRow` + `ToolList` (vue table catégorie) · `FilterSidebar` · `ToolHeader` · `TrustSignals` (**conditionnel** — voir §4) · `Breadcrumb` · `CodeSnippet` (bloc curl + bouton copie) · `ShortcutList` · `RelatedTools`

### E. Briques de workspace partagées
`WorkspaceLayout` (OptionsBar + split panes) · `Pane` (head / body / foot) · `OptionsBar` · `Editor` (numéros de ligne + coloration — utiliser **CodeMirror 6** ou **Shiki**, PAS un highlighter regex maison) · `DropZone` · `ResultPanel` · `SwatchPicker`

### F. Workspaces par outil (un composant chacun, lazy-load)
`JsonFormatter` · `QrGenerator` · `Base64` · `ImageConverter` · `Palette` · `PdfMerge` · `GenericWorkspace` (fallback honnête "interface en cours de design") · puis les autres au fil de l'eau.

### G. Data
Catalogue `tools` typé, `categories`, dictionnaires i18n. Voir §6 pour le schéma.

---

## 4. Trust-signals conditionnels (important pour la crédibilité)

Chaque outil porte un champ `privacy: 'local' | 'network'`. Le composant `TrustSignals` adapte son message — **ne jamais afficher "no logs" en dur sur un outil qui appelle le réseau**.

- **`local`** (défaut, majorité) → point vert :
  - `runs in your browser` / `exécuté dans votre navigateur`
  - `no upload, no logs` / `aucun upload, aucun log`
  - `open-source / MIT`
- **`network`** (IP lookup, SEO analyzer, Meta preview) → point orange :
  - `proxied fetch (server-side)` / `récupération via proxy (serveur)`
  - `request not stored` / `requête non conservée`
  - `open-source / MIT`
  - note : `// requires a network call (CORS / database)`

Les promesses globales (hero, footer) disent **"la plupart des outils"**, pas un absolu.

---

## 5. Faisabilité réelle des outils (pour cadrer les moteurs)

- **100 % navigateur** : JSON, Base64, URL, HTML entities, Case, Word counter, Reverser, Remove line breaks, UUID, Cron, Regex, Markdown→HTML, Password, Palette, Gradient, QR, Hash (Web Crypto + lib MD5), Image converter (Canvas `toBlob`), PDF merge & PDF→image (pdf-lib / pdf.js).
- **Local mais lourd** (ffmpeg.wasm ~25 Mo, lent sur gros fichiers) : Audio & Video converters. PDF↔Word : fidélité médiocre sans serveur.
- **Réseau obligatoire** (→ `privacy: 'network'`) : IP lookup (base géo), SEO analyzer & Meta preview sur URL live (CORS → proxy).

### Libs moteurs (pas du design)
`cmdk` · Web Crypto + lib MD5 · Canvas · `pdf-lib` · `pdf.js` · `ffmpeg.wasm` · lib `qrcode` · CodeMirror 6 / Shiki.

---

## 6. Schéma de données

```ts
type Lang = 'fr' | 'en';
type Localized = Record<Lang, string>;

interface Tool {
  slug: string;              // 'json-formatter'
  cat: 'file' | 'dev' | 'text' | 'design' | 'seo';
  glyph: string;             // "icône" ASCII, ex: "{ }", "▣→▢"
  name: Localized;
  desc: Localized;
  tags: string[];
  runs: number;              // popularité (placeholder, pour le tri)
  dedicated?: boolean;       // true → workspace conçu ; sinon GenericWorkspace
  privacy?: 'local' | 'network'; // défaut 'local'
}

interface Category {
  id: 'all' | 'file' | 'dev' | 'text' | 'design' | 'seo';
  label: Localized;
  glyph: string;
}
```

---

## 7. Ordre de construction conseillé (Phase 1 = premier run)

**Phase 1** (à demander en premier, périmètre serré) :
1. Setup : Next + TS + Tailwind + shadcn + tokens (`tokens.css` → `tailwind.config`)
2. App shell (fond grille/scanline, Header, Footer, ThemeProvider, I18nProvider)
3. `CommandPalette` (cmdk) — la brique de trouvabilité n°1
4. `ToolCard` + `CategorySection` → home sectionnée par catégorie
5. **Un** workspace complet : `JsonFormatter` (bon banc d'essai : split panes + Editor)

**Phase 2** : généralise `WorkspaceLayout` / `Pane` / `OptionsBar`, page catégorie (sidebar + liste), `TrustSignals` conditionnel, puis décline QR / Base64 / Image / Palette / PdfMerge.

**Phase 3** : les outils restants (chacun = un composant workspace lazy-load) + branchement des vrais moteurs (libs §5).

> Ne pas générer les 25 outils d'un coup — périmètre serré par run pour rester vérifiable.

---

## 8. Tweaks à préserver

Le proto expose 3 réglages live (panneau "Tweaks"). À répliquer via CSS variables sur `:root` :
- **Accent** : 4 couleurs (vert `#00e08a`, amber `#ffb454`, violet `#7c5cff`, cyan `#06b6d4`)
- **Densité** : compact / regular / comfy (change le nombre de colonnes de la grille + le padding)
- **Police UI** : geist / inter / ibm
