import type { Config } from "tailwindcss";

/**
 * toolhub — Tailwind config mappé sur handoff/tokens.css
 *
 * Les couleurs pointent vers les CSS variables (définies dans tokens.css) afin
 * que les Tweaks (accent / densité / police) restent pilotables à chaud via
 * les attributs data-* sur <html> sans recompiler Tailwind.
 *
 * Usage : className="bg-bg text-fg border-line" ou "text-accent bg-accent-soft".
 */
const config: Config = {
  darkMode: "class",
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./lib/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        bg: {
          DEFAULT: "var(--bg)",
          1: "var(--bg-1)",
          2: "var(--bg-2)",
          code: "var(--bg-code)",
        },
        line: {
          DEFAULT: "var(--line)",
          2: "var(--line-2)",
        },
        fg: {
          DEFAULT: "var(--fg)",
          1: "var(--fg-1)",
        },
        dim: {
          DEFAULT: "var(--dim)",
          2: "var(--dim-2)",
        },
        accent: {
          DEFAULT: "var(--accent)",
          soft: "var(--accent-soft)",
          mid: "var(--accent-mid)",
        },
        hot: "var(--hot)",
        danger: "var(--danger)",
        syntax: {
          key: "var(--syntax-key)",
          string: "var(--syntax-string)",
          number: "var(--syntax-number)",
          bool: "var(--syntax-bool)",
        },
      },
      fontFamily: {
        // next/font assigne ses variables ; on garde un fallback sur les tokens
        ui: "var(--font-ui)",
        mono: "var(--font-mono)",
      },
      borderRadius: {
        DEFAULT: "var(--radius)",
      },
      maxWidth: {
        shell: "var(--maxw)",
      },
      spacing: {
        // rythme piloté par densité (Tweak)
        pad: "var(--pad)",
        gap: "var(--gap)",
      },
      backgroundImage: {
        // grille de points du fond
        "dot-grid":
          "radial-gradient(circle at 1px 1px, rgba(255,255,255,0.04) 1px, transparent 0)",
      },
      backgroundSize: {
        "dot-grid": "28px 28px",
      },
      keyframes: {
        blink: { to: { visibility: "hidden" } },
        "cp-fade": { from: { opacity: "0" }, to: { opacity: "1" } },
        "cp-pop": {
          from: { transform: "translateY(-8px) scale(0.98)", opacity: "0" },
          to: { transform: "none", opacity: "1" },
        },
      },
      animation: {
        blink: "blink 1s steps(2, start) infinite",
        "cp-fade": "cp-fade 0.12s ease",
        "cp-pop": "cp-pop 0.14s cubic-bezier(0.2, 0.8, 0.2, 1)",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
};

export default config;
