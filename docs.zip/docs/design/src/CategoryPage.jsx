// Category page: breadcrumb + filters + denser list
const { useState: useStateC } = React;

function CategoryPage({ lang, go, route, density }) {
  const t = window.I18N[lang];
  const [activeCat, setActiveCat] = useStateC(route.cat || "all");
  const [sort, setSort] = useStateC("popularity");
  const [q, setQ] = useStateC("");

  const catObj = window.CATEGORIES.find((c) => c.id === activeCat);

  const filtered = window.TOOLS
    .filter((tool) => activeCat === "all" || tool.cat === activeCat)
    .filter((tool) => {
      const ql = q.toLowerCase();
      return (
        !ql ||
        tool.name[lang].toLowerCase().includes(ql) ||
        tool.tags.some((x) => x.includes(ql))
      );
    })
    .sort((a, b) => {
      if (sort === "name") return a.name[lang].localeCompare(b.name[lang]);
      if (sort === "popularity") return b.runs - a.runs;
      return 0;
    });

  return (
    <div className="cat">
      {/* Breadcrumb prompt */}
      <div className="bread">
        <Prompt text={t.promptCat(catObj.label[lang].toLowerCase())} />
        <div className="bread-row mono dim">
          <a onClick={() => go({ view: "home" })} className="bread-link">~</a>
          <span>/</span>
          <a onClick={() => go({ view: "cat", cat: "all" })} className="bread-link">tools</a>
          {activeCat !== "all" && (
            <>
              <span>/</span>
              <span className="bread-here">{catObj.label[lang].toLowerCase()}</span>
            </>
          )}
        </div>
      </div>

      <section className="cat-head">
        <div>
          <div className="cat-glyph mono">{catObj.glyph}</div>
          <h1 className="cat-h1">
            {activeCat === "all"
              ? lang === "fr"
                ? "Tous les outils"
                : "All tools"
              : catObj.label[lang]}
          </h1>
          <p className="cat-sub">
            {activeCat === "all"
              ? lang === "fr"
                ? "Le catalogue complet. Filtrez par catégorie, triez, ou cherchez par nom et tag."
                : "The complete catalog. Filter by category, sort, or search by name and tag."
              : lang === "fr"
              ? `Outils pour ${catObj.label[lang].toLowerCase()}. Tout est traité localement.`
              : `${catObj.label[lang]} tools. Everything runs locally.`}
          </p>
        </div>
        <div className="cat-stats">
          <StatBlock label={t.totalTools} value={String(filtered.length)} />
          <StatBlock
            label={t.runs}
            value={(filtered.reduce((a, b) => a + b.runs, 0) / 1000).toFixed(1) + "k"}
          />
        </div>
      </section>

      {/* Sidebar filter + list */}
      <section className="cat-body">
        <aside className="side">
          <div className="side-head mono dim">// filters</div>
          <div className="side-search">
            <span className="mono dim">{">"}</span>
            <input
              placeholder={t.searchPlaceholder}
              value={q}
              onChange={(e) => setQ(e.target.value)}
              spellCheck={false}
            />
          </div>

          <div className="side-group">
            <div className="side-label mono dim">{t.catLabel}</div>
            <ul className="side-list">
              {window.CATEGORIES.map((c) => {
                const count = c.id === "all" ? window.TOOLS.length : window.TOOLS.filter((x) => x.cat === c.id).length;
                return (
                  <li key={c.id}>
                    <button
                      className={"side-item " + (activeCat === c.id ? "is-on" : "")}
                      onClick={() => setActiveCat(c.id)}
                    >
                      <span className="side-glyph mono">{c.glyph}</span>
                      <span>{c.label[lang]}</span>
                      <span className="side-count mono dim">{count}</span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>

          <div className="side-group">
            <div className="side-label mono dim">{t.sortBy}</div>
            <div className="side-sort">
              {[
                ["popularity", t.sortPop],
                ["name", t.sortName],
                ["new", t.sortNew],
              ].map(([k, lab]) => (
                <button
                  key={k}
                  className={"sort-btn " + (sort === k ? "is-on" : "")}
                  onClick={() => setSort(k)}
                >
                  {lab}
                </button>
              ))}
            </div>
          </div>

          <div className="side-group">
            <div className="side-label mono dim">tags populaires</div>
            <div className="side-tags">
              {["json", "pdf", "image", "encode", "color", "webp", "qr"].map((tg) => (
                <span key={tg} className="tag mono side-tag">
                  #{tg}
                </span>
              ))}
            </div>
          </div>
        </aside>

        <div className="cat-list">
          <div className="list-head mono dim">
            <span style={{ width: 32 }}>#</span>
            <span style={{ width: 52 }}>icon</span>
            <span style={{ flex: 2 }}>name</span>
            <span style={{ flex: 3 }}>description</span>
            <span style={{ width: 90, textAlign: "right" }}>{t.runs}</span>
            <span style={{ width: 32 }} />
          </div>
          {filtered.map((tool, i) => (
            <button key={tool.slug} className="row" onClick={() => go({ view: "tool", slug: tool.slug })}>
              <span className="row-i mono dim">{String(i + 1).padStart(2, "0")}</span>
              <span className="row-glyph mono">{tool.glyph}</span>
              <span className="row-name">
                {tool.name[lang]}
                <span className="row-tag mono dim"> · {window.CATEGORIES.find((c) => c.id === tool.cat).label[lang]}</span>
              </span>
              <span className="row-desc">{tool.desc[lang]}</span>
              <span className="row-runs mono dim">{tool.runs.toLocaleString()}</span>
              <span className="row-arrow mono">→</span>
            </button>
          ))}
          {filtered.length === 0 && (
            <div className="row-empty mono dim">// no match. try clearing filters.</div>
          )}
        </div>
      </section>
    </div>
  );
}

window.CategoryPage = CategoryPage;
