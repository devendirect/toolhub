// Per-tool workspaces — each tool gets its own designed UI (static mocks)
const { useState: useWS } = React;

/* ─────────── helpers ─────────── */

// deterministic pseudo-QR matrix with finder patterns
function makeQrMatrix(n = 25, seed = 7) {
  let s = seed;
  const rnd = () => {
    s = (s * 1103515245 + 12345) & 0x7fffffff;
    return s / 0x7fffffff;
  };
  const m = Array.from({ length: n }, () => Array(n).fill(0));
  const finder = (r, c) => {
    for (let i = -1; i <= 7; i++)
      for (let j = -1; j <= 7; j++) {
        const rr = r + i, cc = c + j;
        if (rr < 0 || cc < 0 || rr >= n || cc >= n) continue;
        const onBorder = i === 0 || i === 6 || j === 0 || j === 6;
        const inCore = i >= 2 && i <= 4 && j >= 2 && j <= 4;
        m[rr][cc] = onBorder || inCore ? 1 : 0;
      }
  };
  for (let r = 0; r < n; r++)
    for (let c = 0; c < n; c++) m[r][c] = rnd() > 0.55 ? 1 : 0;
  finder(0, 0);
  finder(0, n - 7);
  finder(n - 7, 0);
  return m;
}

function QrPreview({ color }) {
  const n = 25;
  const m = makeQrMatrix(n, 11);
  const cell = 8;
  const pad = 16;
  const size = n * cell + pad * 2;
  return (
    <svg width="100%" viewBox={`0 0 ${size} ${size}`} style={{ maxWidth: 260, display: "block", margin: "0 auto" }} shapeRendering="crispEdges">
      <rect width={size} height={size} fill="#ffffff" rx="6" />
      {m.map((row, r) =>
        row.map((v, c) =>
          v ? <rect key={`${r}-${c}`} x={pad + c * cell} y={pad + r * cell} width={cell} height={cell} fill={color} /> : null
        )
      )}
    </svg>
  );
}

function OptionsBar({ children, action }) {
  return (
    <div className="ws-options">
      {children}
      <div className="opt-spacer" />
      {action}
    </div>
  );
}

function Toggle({ on, set }) {
  return (
    <label className="opt-toggle">
      <input type="checkbox" checked={on} onChange={(e) => set(e.target.checked)} />
      <span className="opt-track"><span className="opt-knob" /></span>
    </label>
  );
}

function Seg({ options, value, set }) {
  return (
    <div className="opt-seg">
      {options.map((o) => (
        <button key={o} className={"seg-btn " + (value === o ? "is-on" : "")} onClick={() => set(o)}>
          {o}
        </button>
      ))}
    </div>
  );
}

/* ─────────── 2. QR GENERATOR ─────────── */
function WS_QR({ lang, t }) {
  const [fmt, setFmt] = useWS("SVG");
  const [ec, setEc] = useWS("M");
  const [color, setColor] = useWS("#0a0b0d");
  const presets = ["#0a0b0d", "#00e08a", "#7c5cff", "#06b6d4", "#ffb454"];
  return (
    <section className="ws">
      <OptionsBar
        action={<button className="btn-primary mono">{lang === "fr" ? "générer ⏎" : "generate ⏎"}</button>}
      >
        <div className="opt-block">
          <div className="opt-label mono dim">format</div>
          <Seg options={["SVG", "PNG"]} value={fmt} set={setFmt} />
        </div>
        <div className="opt-block">
          <div className="opt-label mono dim">{lang === "fr" ? "correction" : "error"}</div>
          <Seg options={["L", "M", "Q", "H"]} value={ec} set={setEc} />
        </div>
        <div className="opt-block">
          <div className="opt-label mono dim">{lang === "fr" ? "couleur" : "color"}</div>
          <div className="swatch-row">
            {presets.map((p) => (
              <button key={p} className={"swatch " + (color === p ? "is-on" : "")} style={{ background: p }} onClick={() => setColor(p)} />
            ))}
          </div>
        </div>
      </OptionsBar>

      <div className="ws-split ws-split--qr">
        <div className="pane">
          <div className="pane-head">
            <span className="pane-title mono"><span className="dim">// </span>{t.input}.txt</span>
            <span className="pane-meta mono dim">url / texte</span>
          </div>
          <div className="single-input">
            <span className="si-sigil mono">{">"}</span>
            <span className="si-value mono">https://webbytools.io/json-formatter</span>
            <Cursor />
          </div>
          <div className="field-grid">
            <div className="fg-row"><span className="fg-k mono dim">{lang === "fr" ? "taille" : "size"}</span><span className="fg-v mono">512 × 512 px</span></div>
            <div className="fg-row"><span className="fg-k mono dim">{lang === "fr" ? "marge" : "margin"}</span><span className="fg-v mono">4 modules</span></div>
            <div className="fg-row"><span className="fg-k mono dim">{lang === "fr" ? "fond" : "background"}</span><span className="fg-v mono">#ffffff</span></div>
            <div className="fg-row"><span className="fg-k mono dim">{lang === "fr" ? "capacité" : "capacity"}</span><span className="fg-v mono">~ 1.2k / 2.9k</span></div>
          </div>
        </div>

        <div className="pane">
          <div className="pane-head">
            <span className="pane-title mono"><span className="dim">// </span>{t.output}.{fmt.toLowerCase()}</span>
            <div className="pane-actions">
              <button className="pane-btn">{t.copy}</button>
              <button className="pane-btn">{t.download}</button>
            </div>
          </div>
          <div className="qr-stage">
            <QrPreview color={color} />
            <div className="qr-caption mono dim">{fmt} · {color} · level {ec}</div>
          </div>
          <div className="pane-foot mono dim">
            <span><span className="dot-ok inline" /> 512×512</span>
            <span>{ec === "H" ? "30%" : ec === "Q" ? "25%" : ec === "M" ? "15%" : "7%"} recovery</span>
            <span>{lang === "fr" ? "généré en" : "rendered in"} 4ms</span>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ─────────── 3. BASE64 ─────────── */
const B64_PLAIN = "WebbyTools — fast, private web utilities.\nEverything runs in your browser.";
const B64_ENC = "V2ViYnlUb29scyDigJQgZmFzdCwgcHJpdmF0ZSB3ZWIgdXRpbGl0aWVzLgpFdmVyeXRoaW5nIHJ1bnMgaW4geW91ciBicm93c2VyLg==";

function WS_Base64({ lang, t }) {
  const [mode, setMode] = useWS("encode");
  const [urlSafe, setUrlSafe] = useWS(false);
  const left = mode === "encode" ? B64_PLAIN : B64_ENC;
  const right = mode === "encode" ? B64_ENC : B64_PLAIN;
  return (
    <section className="ws">
      <OptionsBar action={<button className="btn-primary mono">{mode === "encode" ? "encode ⏎" : "decode ⏎"}</button>}>
        <div className="opt-block">
          <div className="opt-label mono dim">mode</div>
          <Seg options={["encode", "decode"]} value={mode} set={setMode} />
        </div>
        <div className="opt-block">
          <div className="opt-label mono dim">URL-safe</div>
          <Toggle on={urlSafe} set={setUrlSafe} />
        </div>
        <div className="opt-block">
          <div className="opt-label mono dim">{lang === "fr" ? "source" : "input"}</div>
          <Seg options={["text", "file"]} value={"text"} set={() => {}} />
        </div>
      </OptionsBar>

      <div className="ws-split">
        <div className="pane">
          <div className="pane-head">
            <span className="pane-title mono"><span className="dim">// </span>{t.input}.{mode === "encode" ? "txt" : "b64"}</span>
            <span className="pane-meta mono dim">{left.length} {t.bytes}</span>
            <div className="pane-actions"><button className="pane-btn">{t.clear}</button></div>
          </div>
          <div className="editor editor--text">
            <pre className="ed-text mono ed-pad">{left}<Cursor /></pre>
          </div>
          <div className="pane-foot mono dim">
            <span><span className="dot-ok inline" /> {mode === "encode" ? "utf-8" : "valid base64"}</span>
            <span>{left.split("\n").length} {t.lines}</span>
          </div>
        </div>

        <div className="pane">
          <div className="pane-head">
            <span className="pane-title mono"><span className="dim">// </span>{t.output}.{mode === "encode" ? "b64" : "txt"}</span>
            <span className="pane-meta mono dim">{right.length} {t.bytes}</span>
            <div className="pane-actions">
              <button className="pane-btn">{t.copy}</button>
              <button className="pane-btn">{t.download}</button>
            </div>
          </div>
          <div className="editor editor--text">
            <pre className="ed-text mono ed-pad ed-accent">{right}</pre>
          </div>
          <div className="pane-foot mono dim">
            <span>{mode === "encode" ? `+${Math.round((right.length / left.length - 1) * 100)}% size` : `−${Math.round((1 - right.length / left.length) * 100)}% size`}</span>
            <span>{urlSafe ? "url-safe alphabet" : "standard alphabet"}</span>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ─────────── 4. IMAGE CONVERTER ─────────── */
function WS_Image({ lang, t }) {
  const [target, setTarget] = useWS("WebP");
  const [quality, setQuality] = useWS(82);
  return (
    <section className="ws">
      <OptionsBar action={<button className="btn-primary mono">{lang === "fr" ? "convertir ⏎" : "convert ⏎"}</button>}>
        <div className="opt-block">
          <div className="opt-label mono dim">{lang === "fr" ? "vers" : "to"}</div>
          <Seg options={["WebP", "PNG", "JPG", "AVIF"]} value={target} set={setTarget} />
        </div>
        <div className="opt-block">
          <div className="opt-label mono dim">{lang === "fr" ? "qualité" : "quality"}</div>
          <input type="range" min="1" max="100" value={quality} onChange={(e) => setQuality(+e.target.value)} className="range" />
          <span className="mono" style={{ width: 32 }}>{quality}</span>
        </div>
        <div className="opt-block">
          <div className="opt-label mono dim">{lang === "fr" ? "redim." : "resize"}</div>
          <Seg options={["100%", "75%", "50%"]} value={"100%"} set={() => {}} />
        </div>
      </OptionsBar>

      <div className="ws-split">
        <div className="pane">
          <div className="pane-head">
            <span className="pane-title mono"><span className="dim">// </span>{lang === "fr" ? "déposer" : "drop"}</span>
            <span className="pane-meta mono dim">jpg · png · webp · gif · avif</span>
          </div>
          <div className="dropzone">
            <div className="dz-glyph mono">▣ → ▢</div>
            <div className="dz-text">{lang === "fr" ? "Glissez une image ici" : "Drop an image here"}</div>
            <div className="dz-sub mono dim">{lang === "fr" ? "ou cliquez pour parcourir · max 50 Mo" : "or click to browse · max 50 MB"}</div>
            <div className="dz-file">
              <span className="dzf-glyph mono">▣</span>
              <div className="dzf-info">
                <div className="dzf-name mono">hero-banner.png</div>
                <div className="dzf-meta mono dim">2400 × 1260 · 3.8 MB · PNG</div>
              </div>
              <div className="dzf-bar"><span style={{ width: "100%" }} /></div>
              <span className="dzf-ok mono">✓</span>
            </div>
          </div>
        </div>

        <div className="pane">
          <div className="pane-head">
            <span className="pane-title mono"><span className="dim">// </span>{t.output}.{target.toLowerCase()}</span>
            <div className="pane-actions">
              <button className="pane-btn">{t.download}</button>
            </div>
          </div>
          <div className="img-result">
            <div className="img-thumb" />
            <div className="img-stats">
              <div className="is-row"><span className="mono dim">{lang === "fr" ? "format" : "format"}</span><span className="mono">PNG → {target}</span></div>
              <div className="is-row"><span className="mono dim">{lang === "fr" ? "dimensions" : "size"}</span><span className="mono">2400 × 1260</span></div>
              <div className="is-row"><span className="mono dim">{lang === "fr" ? "poids" : "weight"}</span><span className="mono">3.8 MB → <span className="ed-accent">412 KB</span></span></div>
              <div className="is-row"><span className="mono dim">{lang === "fr" ? "gain" : "saved"}</span><span className="mono ed-accent">−89%</span></div>
            </div>
          </div>
          <div className="pane-foot mono dim">
            <span><span className="dot-ok inline" /> {lang === "fr" ? "converti" : "converted"}</span>
            <span>q{quality}</span>
            <span>312ms</span>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ─────────── 5. PALETTE GENERATOR ─────────── */
const PALETTES = {
  Analogous: ["#00e08a", "#00c9a7", "#13b1b8", "#2b96c0", "#4a78bf"],
  Complementary: ["#00e08a", "#5fd6a0", "#e8e8ea", "#e0708a", "#e0008a"],
  Triadic: ["#00e08a", "#8a00e0", "#e08a00", "#5fc6a0", "#c68a5f"],
  Monochrome: ["#053d27", "#0a7a4d", "#00e08a", "#5cefb5", "#b0f7da"],
};
function WS_Palette({ lang, t }) {
  const [mode, setMode] = useWS("Analogous");
  const [count, setCount] = useWS(5);
  const cols = PALETTES[mode].slice(0, count);
  return (
    <section className="ws">
      <OptionsBar action={<button className="btn-primary mono">{lang === "fr" ? "générer ⏎" : "generate ⏎"}</button>}>
        <div className="opt-block">
          <div className="opt-label mono dim">base</div>
          <div className="swatch-row">
            <button className="swatch is-on" style={{ background: "#00e08a" }} />
            <span className="mono" style={{ marginLeft: 4 }}>#00e08a</span>
          </div>
        </div>
        <div className="opt-block">
          <div className="opt-label mono dim">{lang === "fr" ? "harmonie" : "harmony"}</div>
          <Seg options={["Analogous", "Complementary", "Triadic", "Monochrome"]} value={mode} set={setMode} />
        </div>
        <div className="opt-block">
          <div className="opt-label mono dim">{lang === "fr" ? "teintes" : "swatches"}</div>
          <Seg options={[3, 4, 5]} value={count} set={setCount} />
        </div>
      </OptionsBar>

      <div className="palette-stage">
        {cols.map((c, i) => (
          <div key={i} className="pal-col" style={{ background: c }}>
            <div className="pal-meta">
              <span className="pal-hex mono">{c.toUpperCase()}</span>
              <span className="pal-copy mono">{t.copy}</span>
            </div>
          </div>
        ))}
      </div>

      <div className="pane pane--standalone">
        <div className="pane-head">
          <span className="pane-title mono"><span className="dim">// </span>export.css</span>
          <div className="pane-actions"><button className="pane-btn">{t.copy}</button><button className="pane-btn">{t.download}</button></div>
        </div>
        <pre className="ed-text mono ed-pad">{`:root {
${cols.map((c, i) => `  --color-${i + 1}: ${c.toUpperCase()};`).join("\n")}
}`}</pre>
      </div>
    </section>
  );
}

/* ─────────── 6. PDF MERGE ─────────── */
const PDF_FILES = [
  { name: "01-cover.pdf", pages: 1, size: "82 KB" },
  { name: "report-q1-2026.pdf", pages: 14, size: "1.2 MB" },
  { name: "appendix-tables.pdf", pages: 6, size: "430 KB" },
  { name: "99-backcover.pdf", pages: 1, size: "76 KB" },
];
function WS_Pdf({ lang, t }) {
  const total = PDF_FILES.reduce((a, b) => a + b.pages, 0);
  return (
    <section className="ws">
      <OptionsBar action={<button className="btn-primary mono">{lang === "fr" ? "fusionner ⏎" : "merge ⏎"}</button>}>
        <div className="opt-block">
          <div className="opt-label mono dim">{lang === "fr" ? "ordre" : "order"}</div>
          <Seg options={[lang === "fr" ? "manuel" : "manual", "A→Z", "Z→A"]} value={lang === "fr" ? "manuel" : "manual"} set={() => {}} />
        </div>
        <div className="opt-block">
          <div className="opt-label mono dim">{lang === "fr" ? "compresser" : "compress"}</div>
          <Toggle on={true} set={() => {}} />
        </div>
        <div className="opt-block">
          <div className="opt-label mono dim">{lang === "fr" ? "signets" : "bookmarks"}</div>
          <Toggle on={false} set={() => {}} />
        </div>
      </OptionsBar>

      <div className="ws-split ws-split--pdf">
        <div className="pane">
          <div className="pane-head">
            <span className="pane-title mono"><span className="dim">// </span>{lang === "fr" ? "fichiers" : "files"} ({PDF_FILES.length})</span>
            <span className="pane-meta mono dim">{total} pages · ~1.8 MB</span>
            <div className="pane-actions"><button className="pane-btn">+ {lang === "fr" ? "ajouter" : "add"}</button></div>
          </div>
          <ul className="pdf-list">
            {PDF_FILES.map((f, i) => (
              <li key={f.name} className="pdf-item">
                <span className="pdf-handle mono dim">⋮⋮</span>
                <span className="pdf-i mono dim">{String(i + 1).padStart(2, "0")}</span>
                <span className="pdf-glyph mono">▤</span>
                <div className="pdf-info">
                  <div className="pdf-name mono">{f.name}</div>
                  <div className="pdf-meta mono dim">{f.pages} {f.pages > 1 ? "pages" : "page"} · {f.size}</div>
                </div>
                <span className="pdf-x mono dim">✕</span>
              </li>
            ))}
          </ul>
          <div className="pdf-drop mono dim">+ {lang === "fr" ? "déposez d'autres PDF ici" : "drop more PDFs here"}</div>
        </div>

        <div className="pane">
          <div className="pane-head">
            <span className="pane-title mono"><span className="dim">// </span>merged.pdf</span>
            <div className="pane-actions"><button className="pane-btn">{t.download}</button></div>
          </div>
          <div className="pdf-preview">
            <div className="pdfp-doc">
              <div className="pdfp-page" />
              <div className="pdfp-page pdfp-page--2" />
              <div className="pdfp-page pdfp-page--3" />
            </div>
            <div className="pdfp-stats">
              <div className="is-row"><span className="mono dim">{lang === "fr" ? "documents" : "documents"}</span><span className="mono">{PDF_FILES.length}</span></div>
              <div className="is-row"><span className="mono dim">{lang === "fr" ? "pages totales" : "total pages"}</span><span className="mono ed-accent">{total}</span></div>
              <div className="is-row"><span className="mono dim">{lang === "fr" ? "poids final" : "final size"}</span><span className="mono">1.6 MB</span></div>
            </div>
          </div>
          <div className="pane-foot mono dim">
            <span><span className="dot-ok inline" /> {lang === "fr" ? "prêt" : "ready"}</span>
            <span>pdf 1.7</span>
            <span>198ms</span>
          </div>
        </div>
      </div>
    </section>
  );
}

window.WORKSPACES = {
  "qr-generator": WS_QR,
  base64: WS_Base64,
  "image-converter": WS_Image,
  "palette-generator": WS_Palette,
  "pdf-merge": WS_Pdf,
};

/* ─────────── GENERIC PREVIEW (tools without a dedicated workspace yet) ─────────── */
function WS_Generic({ lang, t, tool }) {
  const catLabel = window.CATEGORIES.find((c) => c.id === tool.cat).label[lang];
  return (
    <section className="ws">
      <OptionsBar action={<button className="btn-primary mono" disabled style={{ opacity: 0.5, cursor: "not-allowed" }}>{lang === "fr" ? "lancer ⏎" : "run ⏎"}</button>}>
        <div className="opt-block">
          <div className="opt-label mono dim">{lang === "fr" ? "catégorie" : "category"}</div>
          <span className="mono" style={{ fontSize: 12 }}>{catLabel}</span>
        </div>
        <div className="opt-block">
          <div className="opt-label mono dim">{lang === "fr" ? "options" : "options"}</div>
          <span className="mono dim" style={{ fontSize: 12 }}>{tool.tags.length} {lang === "fr" ? "paramètres" : "params"}</span>
        </div>
      </OptionsBar>

      <div className="ws-split">
        <div className="pane">
          <div className="pane-head">
            <span className="pane-title mono"><span className="dim">// </span>{t.input}</span>
            <span className="pane-meta mono dim">{tool.slug}</span>
          </div>
          <div className="single-input">
            <span className="si-sigil mono">{">"}</span>
            <span className="si-value mono dim">{lang === "fr" ? "votre entrée ici…" : "your input here…"}</span>
            <Cursor />
          </div>
          <div className="field-grid">
            {tool.tags.map((tg) => (
              <div className="fg-row" key={tg}>
                <span className="fg-k mono dim">#{tg}</span>
                <span className="fg-v mono dim">—</span>
              </div>
            ))}
          </div>
        </div>

        <div className="pane">
          <div className="pane-head">
            <span className="pane-title mono"><span className="dim">// </span>{t.output}</span>
          </div>
          <div className="generic-stage">
            <div className="gen-glyph mono">{tool.glyph}</div>
            <div className="gen-title">{tool.name[lang]}</div>
            <div className="gen-note mono dim">
              {lang === "fr"
                ? "// interface dédiée en cours de design"
                : "// dedicated UI in design"}
            </div>
            <div className="gen-sub">
              {lang === "fr"
                ? "L'outil est catalogué et prêt à être maquetté. Le moteur tourne déjà côté navigateur."
                : "Tool is cataloged and ready to be mocked. The engine already runs client-side."}
            </div>
            <div className="gen-badges">
              <span className="badge"><span className="badge-dot" /> {lang === "fr" ? "spécifié" : "specced"}</span>
              <span className="badge"><span className="badge-dot" /> {t.inBrowser}</span>
            </div>
          </div>
          <div className="pane-foot mono dim">
            <span><span className="dot-ok inline" /> {lang === "fr" ? "planifié" : "queued"}</span>
            <span>{tool.runs.toLocaleString()} runs</span>
            <span>v0.4.1</span>
          </div>
        </div>
      </div>
    </section>
  );
}

window.WS_Generic = WS_Generic;
