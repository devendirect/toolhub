// Homepage: terminal-style prompt + search + category chips + tool grid
const { useState: useStateH } = React;

function Homepage({ lang, go, accent, density, openPalette }) {
  const t = window.I18N[lang];
  const [activeCat, setActiveCat] = useStateH("all");

  const featured = window.TOOLS[0]; // JSON formatter highlighted

  // grouped sections for "all", flat grid for a single category
  const sections =
    activeCat === "all"
      ? window.CATEGORIES.filter((c) => c.id !== "all").map((c) => ({
          cat: c,
          tools: window.TOOLS.filter((x) => x.cat === c.id),
        }))
      : [
          {
            cat: window.CATEGORIES.find((c) => c.id === activeCat),
            tools: window.TOOLS.filter((x) => x.cat === activeCat),
          },
        ];

  return (
    <div className="home">
      {/* Hero */}
      <section className="hero">
        <div className="hero-frame">
          <div className="frame-corners" aria-hidden>
            <span className="c c-tl">┌</span>
            <span className="c c-tr">┐</span>
            <span className="c c-bl">└</span>
            <span className="c c-br">┘</span>
          </div>

          <div className="hero-meta mono dim">
            <span>session #{Math.floor(Math.random() * 9000 + 1000)}</span>
            <span className="dot-sep">·</span>
            <span>shell zsh</span>
            <span className="dot-sep">·</span>
            <span>{window.TOOLS.length} outils indexés</span>
          </div>

          <h1 className="hero-h1">
            <span className="dim">$</span> {t.tagline}
            <Cursor />
          </h1>

          <p className="hero-sub">
            {lang === "fr"
              ? "Convertir, encoder, générer, formatter. Une commande, un résultat. La plupart des outils tournent 100% en local — vos fichiers ne quittent jamais votre navigateur."
              : "Convert, encode, generate, format. One command, one result. Most tools run fully local — your files never leave your browser."}
          </p>

          <div className="search-wrap">
            <button className="search search--trigger" onClick={openPalette}>
              <span className="search-sigil mono">{">"}</span>
              <span className="search-placeholder mono">{t.searchPlaceholder}</span>
              <kbd className="kbd">⌘</kbd>
              <kbd className="kbd">K</kbd>
            </button>
            <div className="search-hint mono dim">{t.searchHint}</div>
          </div>

          <div className="hero-badges">
            <span className="badge">
              <span className="badge-dot" /> {t.noServer}
            </span>
            <span className="badge">
              <span className="badge-dot" /> {t.inBrowser}
            </span>
            <span className="badge">
              <span className="badge-dot" /> open source
            </span>
          </div>
        </div>

        {/* Hero stats */}
        <aside className="hero-stats">
          <StatBlock label={t.totalTools} value={String(window.TOOLS.length)} sublabel="+ 4 cette semaine" />
          <StatBlock label={t.runs} value="412k" sublabel="dernières 30j" />
          <StatBlock label={t.avgLatency} value="84ms" sublabel="p50 client" />
          <StatBlock label={t.uptime} value="99.98%" sublabel="cdn edge" />
        </aside>
      </section>

      {/* Categories */}
      <section className="cats">
        <div className="cats-head">
          <span className="mono dim">// {t.catLabel.toLowerCase()}</span>
          <span className="cats-rule" />
        </div>
        <div className="chips">
          {window.CATEGORIES.map((c) => (
            <button
              key={c.id}
              className={"chip " + (activeCat === c.id ? "is-on" : "")}
              onClick={() => setActiveCat(c.id)}
            >
              <span className="chip-glyph mono">{c.glyph}</span>
              <span>{c.label[lang]}</span>
              <span className="chip-count mono dim">
                {c.id === "all" ? window.TOOLS.length : window.TOOLS.filter((x) => x.cat === c.id).length}
              </span>
            </button>
          ))}
        </div>
      </section>

      {/* Featured */}
      {activeCat === "all" && (
        <section className="featured">
          <div className="cats-head">
            <span className="mono dim">// {t.featured.toLowerCase()}</span>
            <span className="cats-rule" />
          </div>
          <button className="feat-card" onClick={() => go({ view: "tool", slug: featured.slug })}>
            <div className="feat-left">
              <div className="feat-glyph mono">{featured.glyph}</div>
              <div className="feat-meta mono dim">developer · most used</div>
            </div>
            <div className="feat-mid">
              <div className="feat-name">{featured.name[lang]}</div>
              <div className="feat-desc">{featured.desc[lang]}</div>
              <div className="feat-tags">
                {featured.tags.map((tag) => (
                  <span key={tag} className="tag mono">
                    #{tag}
                  </span>
                ))}
              </div>
            </div>
            <div className="feat-right">
              <div className="feat-runs mono dim">{featured.runs.toLocaleString()} runs</div>
              <div className="feat-cta mono">{t.open} →</div>
            </div>
          </button>
        </section>
      )}

      {/* Tool sections — grouped by category */}
      {sections.map(({ cat, tools }) => (
        <section className="grid-wrap" key={cat.id}>
          <div className="cats-head">
            <span className="mono dim">
              <span className="sec-glyph">{cat.glyph}</span> // {cat.label[lang].toLowerCase()}{" "}
              <span className="hot">{tools.length}</span>
            </span>
            <span className="cats-rule" />
            <button className="sec-more mono dim" onClick={() => go({ view: "cat", cat: cat.id })}>
              {lang === "fr" ? "tout voir" : "view all"} →
            </button>
          </div>

          <div className={`grid grid--${density}`}>
            {tools.map((tool) => (
              <button key={tool.slug} className="tcard" onClick={() => go({ view: "tool", slug: tool.slug })}>
                <div className="tcard-top">
                  <span className="tcard-glyph mono">{tool.glyph}</span>
                  {tool.dedicated ? (
                    <span className="tcard-live mono">● live</span>
                  ) : (
                    <span className="tcard-cat mono dim">{cat.label[lang]}</span>
                  )}
                </div>
                <div className="tcard-name">{tool.name[lang]}</div>
                <div className="tcard-desc">{tool.desc[lang]}</div>
                <div className="tcard-bot">
                  <div className="tcard-tags">
                    {tool.tags.slice(0, 3).map((tag) => (
                      <span key={tag} className="tag mono">
                        #{tag}
                      </span>
                    ))}
                  </div>
                  <div className="tcard-runs mono dim">{(tool.runs / 1000).toFixed(1)}k</div>
                </div>
                <div className="tcard-arrow mono">→</div>
              </button>
            ))}
          </div>
        </section>
      ))}
    </div>
  );
}

window.Homepage = Homepage;
