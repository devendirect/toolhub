// Global ⌘K command palette — fuzzy find across all tools, keyboard-first
const { useState: useCP, useEffect: useEffCP, useRef: useRefCP, useMemo: useMemoCP } = React;

function scoreTool(tool, q, lang) {
  if (!q) return 0;
  const name = tool.name[lang].toLowerCase();
  const tags = tool.tags.join(" ");
  const cat = (window.CATEGORIES.find((c) => c.id === tool.cat).label[lang] || "").toLowerCase();
  const hay = `${name} ${tags} ${cat} ${tool.slug}`;
  if (!hay.includes(q)) {
    // subsequence fuzzy fallback
    let i = 0;
    for (const ch of hay) if (ch === q[i]) i++;
    return i === q.length ? 1 : -1;
  }
  let s = 10;
  if (name.startsWith(q)) s += 100;
  else if (name.includes(q)) s += 50;
  if (tags.includes(q)) s += 20;
  s += Math.min(tool.runs / 5000, 15); // popularity nudge
  return s;
}

function CommandPalette({ open, setOpen, lang, go }) {
  const t = window.I18N[lang];
  const [q, setQ] = useCP("");
  const [sel, setSel] = useCP(0);
  const inputRef = useRefCP(null);
  const listRef = useRefCP(null);

  // reset on open
  useEffCP(() => {
    if (open) {
      setQ("");
      setSel(0);
      setTimeout(() => inputRef.current && inputRef.current.focus(), 30);
    }
  }, [open]);

  // global ⌘K / ctrl+K + esc
  useEffCP(() => {
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setOpen((v) => !v);
      } else if (e.key === "Escape") {
        setOpen(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [setOpen]);

  const ql = q.trim().toLowerCase();

  // build result groups
  const { flat, groups } = useMemoCP(() => {
    if (ql) {
      const ranked = window.TOOLS.map((tool) => ({ tool, s: scoreTool(tool, ql, lang) }))
        .filter((x) => x.s > 0)
        .sort((a, b) => b.s - a.s)
        .map((x) => x.tool);
      return { flat: ranked, groups: null };
    }
    // empty query → popular + by category
    const popular = [...window.TOOLS].sort((a, b) => b.runs - a.runs).slice(0, 4);
    const byCat = window.CATEGORIES.filter((c) => c.id !== "all").map((c) => ({
      cat: c,
      tools: window.TOOLS.filter((tl) => tl.cat === c.id),
    }));
    const flatList = [...popular, ...byCat.flatMap((g) => g.tools)];
    return { flat: flatList, groups: { popular, byCat } };
  }, [ql, lang]);

  const total = flat.length;

  useEffCP(() => {
    if (sel >= total) setSel(Math.max(0, total - 1));
  }, [total]);

  // keyboard nav within palette
  const onInputKey = (e) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setSel((s) => Math.min(total - 1, s + 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setSel((s) => Math.max(0, s - 1));
    } else if (e.key === "Enter") {
      e.preventDefault();
      const tool = flat[sel];
      if (tool) {
        go({ view: "tool", slug: tool.slug });
        setOpen(false);
      }
    }
  };

  // keep selection visible (no scrollIntoView)
  useEffCP(() => {
    const list = listRef.current;
    if (!list) return;
    const el = list.querySelector(`[data-idx="${sel}"]`);
    if (!el) return;
    const top = el.offsetTop;
    const bottom = top + el.offsetHeight;
    if (top < list.scrollTop) list.scrollTop = top - 8;
    else if (bottom > list.scrollTop + list.clientHeight) list.scrollTop = bottom - list.clientHeight + 8;
  }, [sel]);

  if (!open) return null;

  const catLabel = (id) => window.CATEGORIES.find((c) => c.id === id).label[lang];

  const Row = (tool, idx) => (
    <button
      key={tool.slug + idx}
      data-idx={idx}
      className={"cp-row " + (idx === sel ? "is-sel" : "")}
      onMouseEnter={() => setSel(idx)}
      onClick={() => {
        go({ view: "tool", slug: tool.slug });
        setOpen(false);
      }}
    >
      <span className="cp-glyph mono">{tool.glyph}</span>
      <span className="cp-name">{tool.name[lang]}</span>
      <span className="cp-cat mono dim">{catLabel(tool.cat)}</span>
      <span className="cp-tags mono dim">{tool.tags.slice(0, 2).map((x) => "#" + x).join(" ")}</span>
      <span className="cp-arrow mono">↵</span>
    </button>
  );

  let idxCounter = -1;
  const nextIdx = () => ++idxCounter;

  return (
    <div className="cp-scrim" onMouseDown={() => setOpen(false)}>
      <div className="cp-panel" onMouseDown={(e) => e.stopPropagation()}>
        <div className="cp-input">
          <span className="cp-sigil mono">{">"}</span>
          <input
            ref={inputRef}
            className="cp-field mono"
            placeholder={lang === "fr" ? "rechercher un outil, un tag, une catégorie…" : "search a tool, tag, category…"}
            value={q}
            onChange={(e) => {
              setQ(e.target.value);
              setSel(0);
            }}
            onKeyDown={onInputKey}
            spellCheck={false}
          />
          <kbd className="kbd">esc</kbd>
        </div>

        <div className="cp-list" ref={listRef}>
          {total === 0 && (
            <div className="cp-empty mono dim">// {lang === "fr" ? "aucun résultat pour" : "no results for"} "{q}"</div>
          )}

          {groups ? (
            <>
              <div className="cp-group mono dim">{lang === "fr" ? "// populaires" : "// popular"}</div>
              {groups.popular.map((tool) => Row(tool, nextIdx()))}
              {groups.byCat.map((g) => (
                <React.Fragment key={g.cat.id}>
                  <div className="cp-group mono dim">
                    <span className="cp-group-glyph">{g.cat.glyph}</span> // {g.cat.label[lang].toLowerCase()}
                    <span className="cp-group-count">{g.tools.length}</span>
                  </div>
                  {g.tools.map((tool) => Row(tool, nextIdx()))}
                </React.Fragment>
              ))}
            </>
          ) : (
            flat.map((tool) => Row(tool, nextIdx()))
          )}
        </div>

        <div className="cp-foot mono dim">
          <span><kbd className="kbd">↑</kbd><kbd className="kbd">↓</kbd> {lang === "fr" ? "naviguer" : "navigate"}</span>
          <span><kbd className="kbd">↵</kbd> {lang === "fr" ? "ouvrir" : "open"}</span>
          <span><kbd className="kbd">esc</kbd> {lang === "fr" ? "fermer" : "close"}</span>
          <span className="cp-foot-spacer" />
          <span>{total} {lang === "fr" ? "résultats" : "results"}</span>
        </div>
      </div>
    </div>
  );
}

window.CommandPalette = CommandPalette;
