// Shared shell: header, terminal frame, footer
const { useState, useEffect, useRef } = React;

function Cursor() {
  return <span className="cursor">▌</span>;
}

function LogoMark({ size = 28 }) {
  // Recreation of the WebbyTools mark — 2x2 grid: doc, { }, A, image
  const s = size;
  return (
    <svg width={s} height={s} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden>
      {/* outer rounded square */}
      <rect x="4" y="4" width="56" height="56" rx="9" stroke="currentColor" strokeWidth="3.5" />
      {/* cross dividers */}
      <line x1="32" y1="7" x2="32" y2="57" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" />
      <line x1="7" y1="32" x2="57" y2="32" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" />

      {/* Top-left: document */}
      <g stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M14 13 L20 13 L23 16 L23 26 L14 26 Z" fill="none" />
        <line x1="16" y1="20" x2="21" y2="20" />
        <line x1="16" y1="23" x2="21" y2="23" />
      </g>

      {/* Top-right: { } */}
      <g stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" fill="none">
        <path d="M43 13 C40.5 13 40 14.5 40 17 C40 19 39 19.5 38 19.5 C39 19.5 40 20 40 22 C40 24.5 40.5 26 43 26" />
        <path d="M50 13 C52.5 13 53 14.5 53 17 C53 19 54 19.5 55 19.5 C54 19.5 53 20 53 22 C53 24.5 52.5 26 50 26" />
      </g>

      {/* Bottom-left: A */}
      <g stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" fill="none">
        <path d="M13 51 L18.5 38 L24 51" />
        <line x1="15.3" y1="46" x2="21.7" y2="46" />
      </g>

      {/* Bottom-right: image (frame + mountain + sun) */}
      <g stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" fill="none">
        <rect x="38" y="38" width="16" height="13" rx="1.5" />
        <circle cx="42.5" cy="42.5" r="1.4" fill="currentColor" stroke="none" />
        <path d="M38.5 50 L44 44 L48 48 L50.5 45.5 L53.5 50" />
      </g>
    </svg>
  );
}

function Header({ lang, setLang, go, route, openPalette }) {
  const t = window.I18N[lang];
  return (
    <header className="hdr">
      <div className="hdr-inner">
        <button className="logo" onClick={() => go({ view: "home" })} aria-label="WebbyTools home">
          <span className="logo-mark"><LogoMark size={26} /></span>
          <span className="logo-name"><span className="logo-name-1">Webby</span><span className="logo-name-2">Tools</span></span>
          <span className="logo-version mono">v0.4.1</span>
        </button>
        <nav className="hdr-nav">
          <a className={"hdr-link " + (route.view === "home" ? "is-active" : "")} onClick={() => go({ view: "home" })}>
            <span className="dim">/</span>home
          </a>
          <a className={"hdr-link " + (route.view === "cat" ? "is-active" : "")} onClick={() => go({ view: "cat", cat: "all" })}>
            <span className="dim">/</span>tools
          </a>
          <a className="hdr-link">
            <span className="dim">/</span>docs
          </a>
          <a className="hdr-link">
            <span className="dim">/</span>changelog
          </a>
        </nav>
        <div className="hdr-right">
          <button className="hdr-search mono" onClick={openPalette}>
            <span className="dim">{">"}</span>
            <span className="hdr-search-label">{lang === "fr" ? "rechercher" : "search"}</span>
            <kbd className="kbd">⌘K</kbd>
          </button>
          <div className="hdr-status">
            <span className="dot-ok" />
            <span className="mono dim">{t.operational}</span>
          </div>
          <div className="lang-switch">
            <button className={"lang-btn " + (lang === "fr" ? "is-on" : "")} onClick={() => setLang("fr")}>
              fr
            </button>
            <span className="dim">/</span>
            <button className={"lang-btn " + (lang === "en" ? "is-on" : "")} onClick={() => setLang("en")}>
              en
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}

function Prompt({ text, children }) {
  return (
    <div className="prompt-bar">
      <span className="prompt-sigil">$</span>
      <span className="prompt-cmd">{text}</span>
      {children}
      <Cursor />
    </div>
  );
}

function StatBlock({ label, value, sublabel }) {
  return (
    <div className="stat">
      <div className="stat-label mono dim">{label}</div>
      <div className="stat-value">{value}</div>
      {sublabel && <div className="stat-sub mono dim">{sublabel}</div>}
    </div>
  );
}

function Footer({ lang }) {
  const t = window.I18N[lang];
  return (
    <footer className="ftr">
      <div className="ftr-grid">
        <div className="ftr-col">
          <div className="ftr-logo">
            <LogoMark size={32} />
            <span><span className="logo-name-1">Webby</span><span className="logo-name-2">Tools</span></span>
          </div>
          <div className="ftr-tag mono dim">{t.footerTagline}</div>
          <div className="ftr-note mono dim">{t.footerNote}</div>
        </div>
        <div className="ftr-col">
          <div className="ftr-head mono dim">// product</div>
          <a className="ftr-link">{t.docs}</a>
          <a className="ftr-link">{t.api}</a>
          <a className="ftr-link">{t.status}</a>
          <a className="ftr-link">changelog</a>
        </div>
        <div className="ftr-col">
          <div className="ftr-head mono dim">// company</div>
          <a className="ftr-link">{t.about}</a>
          <a className="ftr-link">{t.contact}</a>
          <a className="ftr-link">{t.privacy}</a>
          <a className="ftr-link">github</a>
        </div>
        <div className="ftr-col">
          <div className="ftr-head mono dim">// stack</div>
          <div className="ftr-meta mono dim">built with next.js</div>
          <div className="ftr-meta mono dim">deployed on edge</div>
          <div className="ftr-meta mono dim">© 2026 WebbyTools</div>
        </div>
      </div>
      <div className="ftr-rule" />
      <div className="ftr-bottom mono dim">
        <span>{`> session_end  ::  ${new Date().toISOString().slice(0, 19).replace("T", " ")}`}</span>
        <span>made with caffeine & spite</span>
      </div>
    </footer>
  );
}

Object.assign(window, { Header, Prompt, Footer, Cursor, StatBlock, LogoMark });
