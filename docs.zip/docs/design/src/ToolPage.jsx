// Tool detail page — JSON Formatter mock (static-ish: button toggles example)
const { useState: useStateT } = React;

const SAMPLE_INPUT = `{"user":{"id":42,"name":"Ada Lovelace","email":"ada@example.com","roles":["admin","engineer"],"meta":{"created_at":"2026-04-18T09:14:00Z","plan":"pro","seats":12}},"projects":[{"slug":"webbytools","status":"active"},{"slug":"engine","status":"archived"}]}`;

const SAMPLE_OUTPUT = `{
  "user": {
    "id": 42,
    "name": "Ada Lovelace",
    "email": "ada@example.com",
    "roles": [
      "admin",
      "engineer"
    ],
    "meta": {
      "created_at": "2026-04-18T09:14:00Z",
      "plan": "pro",
      "seats": 12
    }
  },
  "projects": [
    {
      "slug": "webbytools",
      "status": "active"
    },
    {
      "slug": "engine",
      "status": "archived"
    }
  ]
}`;

function syntaxHi(jsonText) {
  // very small syntax highlighter for the mock
  const esc = jsonText
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
  return esc
    .replace(/("(?:\\.|[^"\\])*")(\s*:)/g, '<span class="jk">$1</span>$2')
    .replace(/:\s*("(?:\\.|[^"\\])*")/g, ': <span class="js">$1</span>')
    .replace(/\b(true|false|null)\b/g, '<span class="jb">$1</span>')
    .replace(/(:\s*)(-?\d+(?:\.\d+)?)/g, '$1<span class="jn">$2</span>');
}

function lineNumbers(text) {
  const n = text.split("\n").length;
  return Array.from({ length: n }, (_, i) => i + 1).join("\n");
}

// JSON formatter workspace (default tool)
function WS_Json({ lang, t }) {
  const [indent, setIndent] = useStateT(2);
  const [sortKeys, setSortKeys] = useStateT(false);
  const [minify, setMinify] = useStateT(false);

  const inputBytes = SAMPLE_INPUT.length;
  const outputBytes = SAMPLE_OUTPUT.length;
  const outputLines = SAMPLE_OUTPUT.split("\n").length;
  const outputKeys = (SAMPLE_OUTPUT.match(/"\w+":/g) || []).length;

  return (
    <section className="ws">
      <div className="ws-options">
        <div className="opt-block">
          <div className="opt-label mono dim">{t.indent}</div>
          <div className="opt-seg">
            {[2, 4, 8].map((n) => (
              <button
                key={n}
                className={"seg-btn " + (indent === n ? "is-on" : "")}
                onClick={() => setIndent(n)}
              >
                {n}
              </button>
            ))}
            <button
              className={"seg-btn " + (indent === "tab" ? "is-on" : "")}
              onClick={() => setIndent("tab")}
            >
              tab
            </button>
          </div>
        </div>
        <div className="opt-block">
          <div className="opt-label mono dim">{t.sortKeys}</div>
          <label className="opt-toggle">
            <input type="checkbox" checked={sortKeys} onChange={(e) => setSortKeys(e.target.checked)} />
            <span className="opt-track">
              <span className="opt-knob" />
            </span>
          </label>
        </div>
        <div className="opt-block">
          <div className="opt-label mono dim">{t.minify}</div>
          <label className="opt-toggle">
            <input type="checkbox" checked={minify} onChange={(e) => setMinify(e.target.checked)} />
            <span className="opt-track">
              <span className="opt-knob" />
            </span>
          </label>
        </div>
        <div className="opt-spacer" />
        <button className="btn-primary mono">format ⏎</button>
      </div>

      <div className="ws-split">
        <div className="pane">
          <div className="pane-head">
            <span className="pane-title mono">
              <span className="dim">// </span>
              {t.input}.json
            </span>
            <span className="pane-meta mono dim">
              {inputBytes} {t.bytes}
            </span>
            <div className="pane-actions">
              <button className="pane-btn">{t.paste}</button>
              <button className="pane-btn">{t.clear}</button>
            </div>
          </div>
          <div className="editor">
            <pre className="ed-lines mono">{lineNumbers(SAMPLE_INPUT)}</pre>
            <div className="ed-text mono">
              <span className="ed-raw">{SAMPLE_INPUT}</span>
              <Cursor />
            </div>
          </div>
          <div className="pane-foot mono dim">
            <span>
              <span className="dot-ok inline" /> {t.valid}
            </span>
            <span>utf-8</span>
            <span>ln 1, col {SAMPLE_INPUT.length}</span>
          </div>
        </div>

        <div className="pane">
          <div className="pane-head">
            <span className="pane-title mono">
              <span className="dim">// </span>
              {t.output}.json
            </span>
            <span className="pane-meta mono dim">
              {outputBytes} {t.bytes} · {outputLines} {t.lines} · {outputKeys} {t.keys}
            </span>
            <div className="pane-actions">
              <button className="pane-btn">{t.copy}</button>
              <button className="pane-btn">{t.download}</button>
            </div>
          </div>
          <div className="editor">
            <pre className="ed-lines mono">{lineNumbers(SAMPLE_OUTPUT)}</pre>
            <pre className="ed-text mono" dangerouslySetInnerHTML={{ __html: syntaxHi(SAMPLE_OUTPUT) }} />
          </div>
          <div className="pane-foot mono dim">
            <span>indent: {indent === "tab" ? "tab" : indent + " spaces"}</span>
            <span>sorted: {sortKeys ? "yes" : "no"}</span>
            <span>{lang === "fr" ? "généré en" : "rendered in"} 12ms</span>
          </div>
        </div>
      </div>
    </section>
  );
}

// per-tool snippet + shortcut copy
const TOOL_SNIPPETS = {
  "json-formatter": `curl -X POST https://api.webbytools.io/v1/json/format \\
  -H "content-type: application/json" \\
  -d '{"text":"{\\"a\\":1}","indent":2}'`,
  "qr-generator": `curl https://api.webbytools.io/v1/qr \\
  -G --data-urlencode "data=https://site.io" \\
  -d "format=svg" -d "ec=M" -o qr.svg`,
  base64: `# encode
echo -n "hello" | base64
# decode
echo "aGVsbG8=" | base64 -d`,
  "image-converter": `curl -X POST https://api.webbytools.io/v1/image/convert \\
  -F "file=@hero.png" \\
  -F "to=webp" -F "quality=82" -o hero.webp`,
  "palette-generator": `curl https://api.webbytools.io/v1/palette \\
  -d "base=00e08a" -d "mode=analogous" -d "n=5"`,
  "pdf-merge": `curl -X POST https://api.webbytools.io/v1/pdf/merge \\
  -F "files[]=@a.pdf" -F "files[]=@b.pdf" \\
  -o merged.pdf`,
};

function ToolPage({ lang, go, route }) {
  const t = window.I18N[lang];
  const tool = window.TOOLS.find((x) => x.slug === route.slug) || window.TOOLS[0];
  const Workspace =
    (window.WORKSPACES && window.WORKSPACES[tool.slug]) ||
    (tool.slug === "json-formatter" ? WS_Json : window.WS_Generic) ||
    WS_Json;
  const snippet = TOOL_SNIPPETS[tool.slug] || `# ${tool.slug}\ncurl https://api.webbytools.io/v1/${tool.slug} \\\n  -d "input=..."`;

  return (
    <div className="tool">
      <div className="bread">
        <Prompt text={t.promptTool(tool.slug)} />
        <div className="bread-row mono dim">
          <a onClick={() => go({ view: "home" })} className="bread-link">~</a>
          <span>/</span>
          <a onClick={() => go({ view: "cat", cat: "all" })} className="bread-link">tools</a>
          <span>/</span>
          <span className="bread-here">{tool.slug}</span>
        </div>
      </div>

      <section className="tool-head">
        <div>
          <div className="tool-glyph mono">{tool.glyph}</div>
          <div className="tool-meta mono dim">
            <span>{window.CATEGORIES.find((c) => c.id === tool.cat).label[lang]}</span>
            <span className="dot-sep">·</span>
            <span>{tool.runs.toLocaleString()} runs</span>
            <span className="dot-sep">·</span>
            <span className="hot-text">{t.fast}</span>
          </div>
          <h1 className="tool-h1">{tool.name[lang]}</h1>
          <p className="tool-sub">{tool.desc[lang]}</p>
          <div className="tool-actions">
            <button className="btn-mono">
              <span className="mono">⌘</span> docs
            </button>
            <button className="btn-mono">
              <span className="mono">⌘</span> share
            </button>
            <button className="btn-mono">
              <span className="mono">⌘</span> {lang === "fr" ? "favoris" : "bookmark"}
            </button>
          </div>
        </div>
        <div className="tool-trust">
          {tool.privacy === "network" ? (
            <>
              <div className="trust-row trust-row--net">
                <span className="dot-net" />
                <span className="mono">{lang === "fr" ? "récupération via proxy (serveur)" : "proxied fetch (server-side)"}</span>
              </div>
              <div className="trust-row">
                <span className="dot-ok" />
                <span className="mono">{lang === "fr" ? "requête non conservée" : "request not stored"}</span>
              </div>
              <div className="trust-row">
                <span className="dot-ok" />
                <span className="mono">open-source / MIT</span>
              </div>
              <div className="trust-note mono dim">
                {lang === "fr"
                  ? "// nécessite un appel réseau (CORS / base de données)"
                  : "// requires a network call (CORS / database)"}
              </div>
            </>
          ) : (
            <>
              <div className="trust-row">
                <span className="dot-ok" />
                <span className="mono">{lang === "fr" ? "exécuté dans votre navigateur" : "runs in your browser"}</span>
              </div>
              <div className="trust-row">
                <span className="dot-ok" />
                <span className="mono">{lang === "fr" ? "aucun upload, aucun log" : "no upload, no logs"}</span>
              </div>
              <div className="trust-row">
                <span className="dot-ok" />
                <span className="mono">open-source / MIT</span>
              </div>
            </>
          )}
        </div>
      </section>

      {/* Workspace — dispatched per tool */}
      <Workspace lang={lang} t={t} tool={tool} />

      {/* Examples / API hint */}
      <section className="tool-extras">
        <div className="ex-card">
          <div className="ex-head mono dim">// snippet</div>
          <pre className="ex-code mono">{snippet}</pre>
        </div>
        <div className="ex-card">
          <div className="ex-head mono dim">// shortcuts</div>
          <div className="ex-shortcuts">
            <div><kbd className="kbd">⌘</kbd><kbd className="kbd">⏎</kbd><span className="dim mono">  format</span></div>
            <div><kbd className="kbd">⌘</kbd><kbd className="kbd">C</kbd><span className="dim mono">  copy output</span></div>
            <div><kbd className="kbd">⌘</kbd><kbd className="kbd">K</kbd><span className="dim mono">  another tool</span></div>
            <div><kbd className="kbd">esc</kbd><span className="dim mono">  back</span></div>
          </div>
        </div>
      </section>

      {/* Related */}
      <section className="related">
        <div className="cats-head">
          <span className="mono dim">// {t.relatedTools.toLowerCase()}</span>
          <span className="cats-rule" />
        </div>
        <div className="related-row">
          {window.TOOLS.filter((x) => x.slug !== tool.slug)
            .slice(0, 3)
            .map((rel) => (
              <button key={rel.slug} className="rel-card" onClick={() => go({ view: "tool", slug: rel.slug })}>
                <span className="rel-glyph mono">{rel.glyph}</span>
                <span className="rel-name">{rel.name[lang]}</span>
                <span className="rel-desc">{rel.desc[lang]}</span>
                <span className="rel-arrow mono">→</span>
              </button>
            ))}
        </div>
      </section>
    </div>
  );
}

window.ToolPage = ToolPage;
