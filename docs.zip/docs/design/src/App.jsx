// App router + Tweaks
const { useState: useStateA, useEffect: useEffectA } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#00e08a",
  "density": "regular",
  "fontFamily": "geist",
}/*EDITMODE-END*/;

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [lang, setLang] = useStateA("fr");
  const [route, setRoute] = useStateA({ view: "home" });
  const [paletteOpen, setPaletteOpen] = useStateA(false);

  const go = (r) => {
    setRoute(r);
    window.scrollTo({ top: 0, behavior: "instant" });
  };

  // apply tweaks as CSS vars on :root
  useEffectA(() => {
    const r = document.documentElement;
    r.style.setProperty("--accent", t.accent);
    // derive accent-dim variants
    r.style.setProperty("--accent-soft", t.accent + "22");
    r.style.setProperty("--accent-mid", t.accent + "55");
    r.dataset.density = t.density;
    r.dataset.font = t.fontFamily;
  }, [t.accent, t.density, t.fontFamily]);

  return (
    <div className="app">
      <div className="bg-grid" aria-hidden />
      <div className="bg-scan" aria-hidden />

      <Header lang={lang} setLang={setLang} go={go} route={route} openPalette={() => setPaletteOpen(true)} />

      <main className="main">
        {route.view === "home" && <Homepage lang={lang} go={go} accent={t.accent} density={t.density} openPalette={() => setPaletteOpen(true)} />}
        {route.view === "cat" && <CategoryPage lang={lang} go={go} route={route} density={t.density} />}
        {route.view === "tool" && <ToolPage lang={lang} go={go} route={route} />}
      </main>

      <Footer lang={lang} />

      <CommandPalette open={paletteOpen} setOpen={setPaletteOpen} lang={lang} go={go} />

      <TweaksPanel>
        <TweakSection label="Accent" />
        <TweakColor
          label="Color"
          value={t.accent}
          options={["#00e08a", "#ffb454", "#7c5cff", "#06b6d4"]}
          onChange={(v) => setTweak("accent", v)}
        />
        <TweakSection label="Layout" />
        <TweakRadio
          label="Density"
          value={t.density}
          options={["compact", "regular", "comfy"]}
          onChange={(v) => setTweak("density", v)}
        />
        <TweakSection label="Type" />
        <TweakRadio
          label="UI font"
          value={t.fontFamily}
          options={["geist", "inter", "ibm"]}
          onChange={(v) => setTweak("fontFamily", v)}
        />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
