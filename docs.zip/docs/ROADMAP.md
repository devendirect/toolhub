# Roadmap — toolhub

---

## Phase 1 — Fondations ✅ Fait

1. **Setup** — Next.js + TypeScript + Tailwind v4 + shadcn/ui + tokens CSS (`globals.css`) ✅ Fait
2. **App Shell** — AppShell (dot-grid + scanline), Header, Footer, ThemeProvider, I18nProvider, PaletteProvider ✅ Fait
3. **CommandPalette** — cmdk, scoring custom, groupes populaires / par catégorie, navigation clavier ✅ Fait
4. **Home** — ToolCard, CategorySection, CategoryChips, FeaturedCard, StatBlock, SectionHead, Hero ✅ Fait
5. **Workspace JsonFormatter** — Editor (CodeMirror 6), Pane, OptionsBar + logique format / sort / minify ✅ Fait

---

## Phase 2 — Catalogue + workspaces suivants

### Catalogue
- [x] Page `/tools` — sidebar catégories + liste complète filtrée ✅ Fait
- [x] Page `/tools/[category]` — vue filtrée par catégorie ✅ Fait

### Workspaces
- [x] QR Generator ✅ Fait
- [x] Base64 Encoder / Decoder ✅ Fait
- [x] Image Converter ✅ Fait
- [x] Color Palette Generator ✅ Fait — pure HSL (sans chroma-js)
- [x] PDF Merge ✅ Fait

---

## Phase 3 — Outils restants

- [x] Hash Generator ✅ Fait
- [x] Markdown → HTML ✅ Fait
- [x] Regex Tester ✅ Fait
- [x] IP Lookup ✅ Fait
- [x] UUID Generator ✅ Fait
- [x] Cron Generator ✅ Fait
- [x] Case Converter ✅ Fait
- [x] Word Counter ✅ Fait
- [x] Remove Line Breaks ✅ Fait
- [x] Text Reverser ✅ Fait
- [x] URL Encoder / Decoder ✅ Fait
- [x] HTML Entities ✅ Fait
- [x] Audio Converter ✅ Fait
- [x] Video Converter ✅ Fait
- [x] PDF Converter ✅ Fait
- [x] Password Generator ✅ Fait
- [x] Gradient Generator ✅ Fait
- [x] Meta Tag Preview ✅ Fait
- [x] SEO Analyzer ✅ Fait

---

## Hors phases — à faire quand pertinent

- [x] Tweaks panel (accent / densité / police) ✅ Fait — bouton `⊞` dans le Header, Popover shadcn, `SegControl` pour density/font, swatches colorés pour accent, reset to defaults
- [ ] Gestion des cookies / consentement RGPD — **à implémenter avec GA4** (voir `docs/monetisation/ga4-cookie-consent.md`). GA4 pose des cookies → bandeau obligatoire UE. Stack retenue : `react-cookie-consent` + chargement conditionnel de GA4. EthicalAds et Carbon Ads restent sans cookie.
- [x] Toast "copié !" (Sonner) sur les boutons copier ✅ Fait — hook `useCopy` partagé
- [x] `DropZone` — drag & drop de fichiers pour les outils fichiers ✅ Fait — `DropZone` + `DropZoneMulti`
- [ ] **Rebrand** — remplacer "toolhub" par le vrai nom : `BRAND_NAME` dans `lib/brand.ts`, `name` dans `package.json`, copyright dans `LICENSE`, repo GitHub, domaine. À faire avant tout lancement public.
- [x] SEO — `generateMetadata` sur toutes les pages ✅ Fait — home, /tools, /tools/[category], /t/[slug], /about. Tout passe par `BRAND_NAME`
- [x] Page `/about` — **attributions des librairies open source** ✅ Fait (obligatoire LGPL pour FFmpeg, bonne pratique pour les MIT) : CodeMirror, FFmpeg, marked, pdf-lib, qrcode, cronstrue, cheerio, cmdk, shadcn/ui
- [x] Bouton **Share** dans `ToolHeader` ✅ Fait — `navigator.share()` natif + fallback `clipboard.writeText(url)`, feedback "copié !" 2s
- [ ] **Docs par outil** — supprimé du header (bouton décoratif sans contenu). À envisager si la base d'utilisateurs grandit : une section statique sous chaque workspace (MDX ou simple JSX) expliquant les options et les cas d'usage. Représente ~25 pages de contenu à rédiger + un système de rendu. Pas prioritaire.
- [x] **Favoris / Bookmarks** ✅ Fait — `FavoritesProvider` + hook `useFavorites()`, persistance `localStorage` (`toolhub-favorites`). Bouton `☆/★` dans `ToolHeader`, section dynamique sur la home (si > 0 favoris), filtre `★ Favoris (N)` en tête de sidebar dans `/tools`.

---

## Outils futurs — idées par catégorie

> Outils non présents dans le catalogue initial. À prioriser selon les stats GA4 (`tool_run` par slug) et les retours utilisateurs.

### Fichiers
| Outil | Description | Moteur |
|---|---|---|
| Image Compressor | Réduire le poids d'une image sans perte visible | `browser-image-compression` (npm) |
| HEIC → JPG | Convertir les photos iPhone (HEIC/HEIF) | `heic2any` (npm) |
| SVG Optimizer | Nettoyer et minifier un SVG | `svgo` (npm) |
| ZIP Extractor | Extraire un .zip dans le navigateur | `fflate` (npm) |
| File Size Reducer | Compresser PDF / image en lot | `pdf-lib` + Canvas |

### Développeur
| Outil | Description | Moteur |
|---|---|---|
| JWT Decoder | Décoder et vérifier un token JWT | Code custom (`atob` + JSON.parse) |
| Timestamp Converter | Unix timestamp ↔ date lisible | Code custom (`Date`) |
| Number Base Converter | Décimal ↔ Hex ↔ Binaire ↔ Octal | Code custom |
| Diff Viewer | Comparer deux textes ligne par ligne | `diff` (npm) |
| CSS Minifier | Minifier du CSS | `clean-css` (npm) |
| .env Formatter | Valider et trier un fichier `.env` | Code custom (regex) |
| Color Picker | Sélecteur de couleur avec conversions HEX/RGB/HSL | Code custom + EyeDropper API |

### Texte
| Outil | Description | Moteur |
|---|---|---|
| Lorem Ipsum Generator | Générer du faux texte | Code custom |
| Text Diff | Comparer deux blocs de texte | `diff` (npm) |
| Duplicate Line Remover | Supprimer les doublons d'une liste | Code custom |
| CSV ↔ JSON | Convertir entre CSV et JSON | Code custom |
| String Escape | Échapper/désechapper JS, SQL, Bash | Code custom (regex) |
| Slug Generator | Convertir un titre en slug URL-friendly | Code custom |

### Design
| Outil | Description | Moteur |
|---|---|---|
| Box Shadow Generator | Générateur de `box-shadow` CSS visuel | Code custom |
| Border Radius Generator | Générateur de `border-radius` CSS visuel | Code custom |
| Favicon Generator | Créer un favicon PNG/ICO depuis texte ou SVG | Canvas API |
| Color Contrast Checker | Vérifier le ratio de contraste WCAG AA/AAA | Code custom |
| CSS Grid Generator | Générateur de grille CSS visuel | Code custom |

### SEO
| Outil | Description | Moteur |
|---|---|---|
| Robots.txt Generator | Générer un fichier `robots.txt` | Code custom |
| Sitemap Generator | Générer un sitemap XML depuis une liste d'URLs | Code custom |
| Schema Markup Generator | Générer du JSON-LD (Article, Product, FAQ…) | Code custom |
| Open Graph Checker | Vérifier les balises OG (déjà couvert par Meta Preview) | Route Handler |

### Finance *(nouvelle catégorie)*
| Outil | Description | Moteur |
|---|---|---|
| Currency Converter | Convertir entre devises avec taux temps réel | Route Handler + **frankfurter.app** (gratuit, sans clé, géré par Wise) |

> Tous les outils Finance sont `privacy: 'network'` — taux de change non disponibles en local. Cache TTL 1h suffisant (les taux ne changent pas à la seconde pour un usage grand public). Trust signal orange obligatoire.

---

## Moteurs par outil

Légende :
- **Code custom** — logique écrite nous-mêmes, pas de dépendance externe
- **API navigateur** — fonctions natives du browser (pas de lib à installer)
- **Lib npm** — package à installer
- **Route Handler** — endpoint Next.js côté serveur (outils `privacy: 'network'`)
- **API externe** — service tiers appelé côté serveur

---

### Fichiers

| Outil | Moteur | Type |
|---|---|---|
| Image Converter | `Canvas.toBlob()` + `FileReader` | API navigateur — code custom |
| PDF Converter | `pdf-lib` (création/édition PDF) + `pdf.js` (lecture/rendu) | Lib npm |
| Audio Converter | `@ffmpeg/ffmpeg` + `@ffmpeg/util` (~25 Mo WASM, lazy-load obligatoire) | Lib npm |
| Video Converter | `@ffmpeg/ffmpeg` + `@ffmpeg/util` (même bundle que audio) | Lib npm |
| PDF Merge | `pdf-lib` — `PDFDocument.copyPages()` | Lib npm |

> Audio et Video partagent le même bundle ffmpeg.wasm. Le charger une fois suffit pour les deux.

---

### Développeur

| Outil | Moteur | Type |
|---|---|---|
| QR Generator | `qrcode` (génère SVG ou PNG canvas) | Lib npm |
| Base64 | `TextEncoder` / `TextDecoder` + `btoa` / `atob` natifs | API navigateur — code custom |
| Markdown → HTML | `marked` (rapide, léger) ou `remark` (si besoin plugins) | Lib npm |
| Hash Generator | `crypto.subtle` (SHA-1/256/512) + `spark-md5` (MD5, car Web Crypto ne supporte pas MD5) | API navigateur + lib npm |
| Regex Tester | `RegExp` natif JS | API navigateur — code custom |
| IP Lookup | `ip-api.com` (gratuit, pas de clé pour usage modéré) via Route Handler | Route Handler + API externe |
| UUID Generator | `crypto.randomUUID()` natif (v4) + code custom pour v1/v7 | API navigateur — code custom |
| Cron Generator | `cronstrue` (traduit une expression cron en texte lisible) | Lib npm |

---

### Texte

| Outil | Moteur | Type |
|---|---|---|
| JSON Formatter ✅ | `JSON.parse` / `JSON.stringify` natifs | API navigateur — code custom |
| Case Converter | Manipulation de string JS pure | Code custom |
| Word Counter | `Intl.Segmenter` (découpage correct multi-langue) | API navigateur — code custom |
| Remove Line Breaks | Regex JS (`/\r?\n/g`) | Code custom |
| Text Reverser | `Array.from().reverse()` (gère l'Unicode/emojis) | Code custom |
| URL Encoder / Decoder | `encodeURIComponent` / `decodeURIComponent` natifs | API navigateur — code custom |
| HTML Entities | `DOMParser` natif (encode/decode via le DOM) | API navigateur — code custom |

---

### Design

| Outil | Moteur | Type |
|---|---|---|
| Color Palette Generator | `chroma-js` (manipulation couleurs, harmonies, conversions) | Lib npm |
| Password Generator | `crypto.getRandomValues()` natif | API navigateur — code custom |
| Gradient Generator | Génération de `linear-gradient` / `radial-gradient` CSS en pur JS | Code custom |

---

### SEO / Marketing

| Outil | Moteur | Type |
|---|---|---|
| Meta Tag Preview | Route Handler qui fetch l'URL → parse `<meta>` avec `cheerio` → retourne JSON | Route Handler + lib npm (`cheerio`) |
| SEO Analyzer | Route Handler qui fetch l'URL → analyse avec `cheerio` (titres, Hn, mots…) | Route Handler + lib npm (`cheerio`) |
| IP Lookup | Route Handler → `ip-api.com` | Route Handler + API externe |

---

## Dépendances npm à installer (résumé)

```bash
# Phase 2
npm install qrcode
npm install @types/qrcode -D

# Phase 3 — au fil de l'eau
npm install marked                        # Markdown → HTML
npm install spark-md5                     # MD5 (Web Crypto ne le supporte pas)
npm install @types/spark-md5 -D
npm install cronstrue                     # Cron → texte lisible
npm install chroma-js                     # Palette couleurs
npm install @types/chroma-js -D
npm install pdf-lib                       # PDF Merge + PDF Converter
npm install cheerio                       # Meta Preview + SEO Analyzer (serveur)
npm install @ffmpeg/ffmpeg @ffmpeg/util   # Audio + Video (lourd, lazy-load)
```

> `pdf.js` est disponible via `pdfjs-dist` mais souvent plus simple à charger via CDN en lazy-load pour les workspaces fichiers.
